"use client";

import { useMemo, useSyncExternalStore } from "react";

import { useToday } from "@/hooks/use-student-portal";
import { buildCatalog } from "@/lib/resources/catalog";
import {
  getServerSnapshot,
  getSnapshot,
  resourceActions,
  subscribe,
} from "@/lib/storage/resource-store";
import type { ResourceCatalogData } from "@/lib/storage/resource-sanitize";
import type { DateOnlyString, SupportResource } from "@/types";

export interface ResourceCatalog {
  today: DateOnlyString;
  /** Every listing, including archived and expired ones. */
  resources: SupportResource[];
  stored: ResourceCatalogData;
  actions: typeof resourceActions;
}

/** The funding catalog for administrators. Null until the browser has loaded. */
export function useResourceCatalog(): ResourceCatalog | null {
  const stored = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const today = useToday();
  const resources = useMemo(
    () => (today && stored ? buildCatalog(today, stored) : []),
    [today, stored],
  );
  if (!today || !stored) return null;
  return { today, resources, stored, actions: resourceActions };
}
