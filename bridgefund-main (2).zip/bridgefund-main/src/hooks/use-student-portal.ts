"use client";

import { useMemo, useSyncExternalStore } from "react";

import { todayISO } from "@/lib/dates";
import { buildCatalog } from "@/lib/resources/catalog";
import {
  getServerSnapshot as getCatalogServerSnapshot,
  getSnapshot as getCatalogSnapshot,
  subscribe as subscribeCatalog,
} from "@/lib/storage/resource-store";
import {
  getPersistFailedServerSnapshot,
  getPersistFailedSnapshot,
  getServerSnapshot,
  getSnapshot,
  studentActions,
  subscribe,
} from "@/lib/storage/student-store";
import type { DateOnlyString, StudentData, SupportResource } from "@/types";

const noopSubscribe = () => () => {};

/** Today's local date. Null on the server so nothing time-based is prerendered. */
export function useToday(): DateOnlyString | null {
  return useSyncExternalStore(noopSubscribe, todayISO, () => null);
}

export interface StudentPortal {
  data: StudentData;
  today: DateOnlyString;
  /**
   * The full funding catalog, including archived and expired listings so saved
   * plans can still look them up. The matching engine excludes archived and
   * expired listings on its own; use `listable()` before showing a browse list.
   * Fictional demo data (labelled DEMO DATA) until a verified catalog exists.
   */
  resources: SupportResource[];
  actions: typeof studentActions;
  /** True when the browser refused to save (changes last only this session). */
  persistFailed: boolean;
}

/**
 * Everything a student-portal screen needs. Returns null until the browser
 * has loaded (server render and first paint), so callers show a skeleton.
 */
export function useStudentPortal(): StudentPortal | null {
  const data = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const persistFailed = useSyncExternalStore(
    subscribe,
    getPersistFailedSnapshot,
    getPersistFailedServerSnapshot,
  );
  const catalog = useSyncExternalStore(
    subscribeCatalog,
    getCatalogSnapshot,
    getCatalogServerSnapshot,
  );
  const today = useToday();
  const resources = useMemo(
    () => (today && catalog ? buildCatalog(today, catalog) : []),
    [today, catalog],
  );

  if (!data || !today || !catalog) return null;
  return { data, today, resources, actions: studentActions, persistFailed };
}
