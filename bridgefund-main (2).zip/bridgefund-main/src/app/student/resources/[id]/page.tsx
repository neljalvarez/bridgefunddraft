import type { Metadata } from "next";
import { Suspense } from "react";

import { PortalSkeleton } from "@/components/shared/portal-skeleton";
import { ResourceDetailView } from "@/components/student/resource-detail-view";

export const metadata: Metadata = { title: "Funding listing" };

interface PageProps {
  params: Promise<{ id: string }>;
}

async function Detail({ params }: PageProps) {
  const { id } = await params;
  return <ResourceDetailView id={id} />;
}

export default function StudentResourceDetailPage({ params }: PageProps) {
  // Reading params is runtime data under Cache Components, so it sits inside Suspense.
  return (
    <Suspense fallback={<PortalSkeleton />}>
      <Detail params={params} />
    </Suspense>
  );
}
