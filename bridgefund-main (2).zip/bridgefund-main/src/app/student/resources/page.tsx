import type { Metadata } from "next";

import { PageHeader } from "@/components/layout/page-header";
import { ResourcesView } from "@/components/student/resources-view";

export const metadata: Metadata = { title: "Find Funding" };

export default function StudentResourcesPage() {
  return (
    <>
      <PageHeader
        title="Find Funding"
        description="Search funding listings and see how well each one fits the costs you entered. Fictional demo listings are labelled DEMO DATA."
      />
      <ResourcesView />
    </>
  );
}
