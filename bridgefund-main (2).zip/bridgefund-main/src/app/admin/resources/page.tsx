import type { Metadata } from "next";

import { AdminGate } from "@/components/admin/admin-gate";
import { ResourcesAdminView } from "@/components/admin/resources-admin-view";
import { PageHeader } from "@/components/layout/page-header";

export const metadata: Metadata = { title: "Funding resources" };

export default function AdminResourcesPage() {
  return (
    <>
      <PageHeader
        title="Funding resources"
        description="Create, edit, verify, expire, and archive the funding listings students are matched to."
      />
      <AdminGate>
        <ResourcesAdminView />
      </AdminGate>
    </>
  );
}
