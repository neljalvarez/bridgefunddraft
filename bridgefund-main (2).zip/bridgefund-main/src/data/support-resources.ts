import { addDays } from "@/lib/dates";
import type {
  Criterion,
  DateOnlyString,
  ResourceEligibility,
  SupportResource,
} from "@/types";

/**
 * FICTIONAL DEMO CATALOG: every listing here is DEMO DATA.
 *
 * Every organization, program, amount, and link is invented for demonstration
 * (links use the reserved example.org domain). Nothing here is a real funding
 * program and none of it promises that any funding exists. Deadlines roll
 * forward with `today` so the demo never goes stale. In production this is
 * replaced by listings an administrator has actually verified.
 *
 * The listings deliberately cover every verification state and several
 * UNKNOWN rules so the matching engine's handling of them is visible.
 */

/** Residence countries used by the demo regional programs. */
const EUROPE = ["PT", "ES", "FR", "DE", "IT", "NL", "BE", "AT", "IE", "PL", "GR", "FI", "SE", "DK"];
const GULF_AND_SOUTH_ASIA = ["AE", "SA", "QA", "IN", "PK", "LK", "BD", "NP"];
const AFRICA_DEMO = ["KE", "NG", "GH", "ZA", "UG", "TZ", "RW", "ZM"];

const any: Criterion<never> = { mode: "any" };
const unknown: Criterion<never> = { mode: "unknown" };
const only = <T extends string>(...values: T[]): Criterion<T> => ({ mode: "only", values });

export const DEMO_RESOURCE_IDS = {
  openDoorsWaiver: "res-open-doors-waiver",
  examVoucher: "res-meridian-exam-voucher",
  examSponsor: "res-northlight-exam-sponsor",
  tuitionGrant: "res-learning-bridge-grant",
  skillsSponsorship: "res-brightpath-sponsorship",
  laptopLoan: "res-community-laptop-loan",
  connectivity: "res-signal-connectivity",
  textbooks: "res-openshelf-textbooks",
  practiceExams: "res-openshelf-practice",
  transport: "res-harbourline-transport",
  intlTravel: "res-harbourline-intl-travel",
  housing: "res-lantern-housing",
  supplies: "res-northlight-supplies",
  // Added with the funding resource database.
  graduateStipend: "res-kestrel-graduate-stipend",
  baobabFund: "res-baobab-learners-fund",
  digitalAccess: "res-crescent-digital-access",
  transitPass: "res-pathfinder-transit-pass",
  bootcampBursary: "res-ember-bootcamp-bursary",
  retakeGrant: "res-tidewater-retake-grant",
} as const;

const DEMO_NOTE =
  "DEMO DATA: an illustrative verification record. Nothing real was checked.";

export function getSupportResources(today: DateOnlyString): SupportResource[] {
  const site = (slug: string) => `https://example.org/demo/${slug}`;
  const verifiedDaysAgo = (n: number) => ({
    verification: "verified" as const,
    lastVerifiedDate: addDays(today, -n),
    verificationNote: DEMO_NOTE,
  });

  /** Fields every demo listing shares; each entry overrides what differs. */
  const demo = (
    r: Omit<SupportResource, "isDemo" | "eligibility"> & {
      eligibility: Partial<ResourceEligibility> & { summary: string };
    },
  ): SupportResource => ({
    ...r,
    eligibility: {
      residence: any,
      studyCountries: any,
      educationLevels: any,
      opportunityTypes: any,
      fieldsOfStudy: any,
      enrollment: any,
      needBased: "no",
      additionalRequirements: [],
      ...r.eligibility,
    },
    isDemo: true,
  });

  return [
    demo({
      id: DEMO_RESOURCE_IDS.openDoorsWaiver,
      name: "Open Doors Application Fee Waiver",
      provider: "Open Doors Access Trust",
      description:
        "Covers application and registration fees for students who cannot pay them.",
      country: "GLOBAL",
      kind: "fee_waiver",
      categories: ["application_fees"],
      eligibility: {
        summary: "Any student applying to a program, course, or scholarship. Need-based.",
        opportunityTypes: only("program", "course", "scholarship"),
        needBased: "yes",
      },
      value: { kind: "full" },
      deadlineType: "fixed",
      deadline: addDays(today, 40),
      officialUrl: site("open-doors-waiver"),
      sourceName: "Open Doors Access Trust",
      applicationInstructions:
        "Request the waiver code on the provider’s page before you pay the application fee, then enter it at checkout.",
      ...verifiedDaysAgo(20),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.examVoucher,
      name: "Examination Access Voucher",
      provider: "Meridian Certification Board",
      description: "A voucher that reduces the registration fee for certification exams.",
      country: "GLOBAL",
      kind: "fee_waiver",
      categories: ["exam_fees"],
      eligibility: {
        summary: "Students registering for a certification exam. Need-based.",
        opportunityTypes: only("exam"),
        needBased: "yes",
      },
      value: { kind: "fixed", amount: 100, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 25),
      officialUrl: site("exam-access-voucher"),
      sourceName: "Meridian Certification Board",
      applicationInstructions:
        "Submit the short voucher request form at least 5 working days before your exam date.",
      ...verifiedDaysAgo(35),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.examSponsor,
      name: "Northlight Exam Sponsorship",
      provider: "Northlight Education Fund",
      description: "Sponsors half of an exam fee for eligible learners.",
      country: "GLOBAL",
      kind: "sponsorship",
      categories: ["exam_fees"],
      eligibility: {
        summary: "Open to learners in any country sitting a certification exam.",
        opportunityTypes: only("exam"),
      },
      value: { kind: "percent", percent: 50 },
      deadlineType: "fixed",
      deadline: addDays(today, 50),
      officialUrl: site("northlight-exam-sponsorship"),
      sourceName: "Northlight Education Fund",
      applicationInstructions:
        "Apply online with your exam registration confirmation. Decisions are emailed.",
      ...verifiedDaysAgo(60),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.tuitionGrant,
      name: "Learning Bridge Tuition Grant",
      provider: "Learning Bridge Foundation",
      description: "A grant toward programme and course fees for students in Europe.",
      country: "EU",
      kind: "grant",
      categories: ["tuition"],
      eligibility: {
        summary:
          "Residents of Europe in formal or vocational study, for programs and courses. Need-based.",
        residence: only(...EUROPE),
        educationLevels: only("undergraduate", "graduate", "vocational", "other"),
        opportunityTypes: only("program", "course"),
        needBased: "yes",
      },
      value: { kind: "fixed", amount: 600, currency: "EUR" },
      deadlineType: "fixed",
      deadline: addDays(today, 30),
      officialUrl: site("learning-bridge-grant"),
      sourceName: "Learning Bridge Foundation",
      applicationInstructions:
        "Complete the online form and upload your course offer letter. Award notices follow within four weeks.",
      ...verifiedDaysAgo(15),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.skillsSponsorship,
      name: "Brightpath Skills Sponsorship",
      provider: "Brightpath Skills Alliance",
      description: "Industry-funded sponsorship of a quarter of programme fees.",
      country: "GLOBAL",
      kind: "sponsorship",
      categories: ["tuition"],
      eligibility: {
        summary: "Students in any country joining a skills program or course.",
        opportunityTypes: only("program", "course"),
      },
      value: { kind: "percent", percent: 25 },
      deadlineType: "fixed",
      deadline: addDays(today, 60),
      officialUrl: site("brightpath-sponsorship"),
      sourceName: "Brightpath Skills Alliance",
      applicationInstructions: "Apply through the alliance’s sponsorship page.",
      verification: "unverified",
    }),
    demo({
      id: DEMO_RESOURCE_IDS.laptopLoan,
      name: "Community Laptop Library",
      provider: "Community Laptop Library Network",
      description:
        "Borrow a laptop for the length of your course instead of buying or renting one.",
      country: "EU",
      kind: "equipment_loan",
      categories: ["technology"],
      eligibility: {
        summary: "Students in Europe enrolled in or joining a course or program.",
        residence: only(...EUROPE),
        enrollment: only("enrolled", "applying"),
      },
      value: { kind: "full" },
      deadlineType: "rolling",
      officialUrl: site("laptop-library"),
      sourceName: "Community Laptop Library Network",
      applicationInstructions:
        "Reserve a laptop at your nearest library hub. Bring proof of enrollment or your offer letter.",
      ...verifiedDaysAgo(45),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.connectivity,
      name: "Signal Connectivity Stipend",
      provider: "Signal Connectivity Fund",
      description:
        "A one-off stipend toward internet access and devices for study. Need-based.",
      country: "GLOBAL",
      kind: "grant",
      categories: ["technology"],
      eligibility: { summary: "Students in any country. Need-based.", needBased: "yes" },
      value: { kind: "fixed", amount: 80, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 45),
      officialUrl: site("connectivity-stipend"),
      sourceName: "Signal Connectivity Fund",
      applicationInstructions: "Apply online. The stipend is paid to your mobile-money or bank account.",
      ...verifiedDaysAgo(10),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.textbooks,
      name: "OpenShelf Open Textbooks",
      provider: "OpenShelf Learning Commons",
      description:
        "Openly licensed textbooks and course readings you can use instead of buying books.",
      country: "GLOBAL",
      kind: "free_alternative",
      categories: ["learning_materials"],
      eligibility: { summary: "Free for everyone." },
      value: { kind: "full" },
      deadlineType: "rolling",
      officialUrl: site("openshelf-textbooks"),
      sourceName: "OpenShelf Learning Commons",
      applicationInstructions: "No application. Search the catalog and download or read online.",
      ...verifiedDaysAgo(90),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.practiceExams,
      name: "OpenShelf Practice Exam Bank",
      provider: "OpenShelf Learning Commons",
      description: "Free community-written practice questions in place of a paid practice bundle.",
      country: "GLOBAL",
      kind: "free_alternative",
      categories: ["learning_materials"],
      eligibility: {
        summary: "Free for everyone preparing for an exam or course.",
        opportunityTypes: only("exam", "course"),
      },
      value: { kind: "full" },
      deadlineType: "rolling",
      officialUrl: site("openshelf-practice-exams"),
      sourceName: "OpenShelf Learning Commons",
      applicationInstructions: "No application. Create a free account to save your progress.",
      ...verifiedDaysAgo(90),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.transport,
      name: "Harbourline Student Travel Grant",
      provider: "Harbourline Mobility Fund",
      description: "Helps with travel to classes, interviews, and exam centres within Europe.",
      country: "EU",
      kind: "grant",
      categories: ["transportation"],
      eligibility: {
        summary: "Residents of Europe. Need-based.",
        residence: only(...EUROPE),
        needBased: "yes",
      },
      value: { kind: "fixed", amount: 150, currency: "EUR" },
      deadlineType: "fixed",
      deadline: addDays(today, 35),
      officialUrl: site("harbourline-travel-grant"),
      sourceName: "Harbourline Mobility Fund",
      applicationInstructions:
        "Apply with a travel quote or ticket. Receipts are required after travel.",
      ...verifiedDaysAgo(25),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.intlTravel,
      name: "Harbourline International Travel Award",
      provider: "Harbourline Mobility Fund",
      description: "A travel award for students going abroad for study.",
      country: "GLOBAL",
      kind: "grant",
      categories: ["transportation"],
      eligibility: {
        summary: "Students in any country travelling abroad to study.",
        additionalRequirements: ["Must be travelling abroad to study"],
      },
      value: { kind: "fixed", amount: 100, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 70),
      officialUrl: site("harbourline-international-travel"),
      sourceName: "Harbourline Mobility Fund",
      applicationInstructions: "Apply on the fund’s website with your travel dates.",
      verification: "unverified",
    }),
    demo({
      id: DEMO_RESOURCE_IDS.housing,
      name: "Lantern Housing Bursary",
      provider: "Lantern Student Housing Trust",
      description: "A bursary toward short-term accommodation during study.",
      country: "EU",
      kind: "grant",
      categories: ["housing"],
      eligibility: {
        summary: "Enrolled undergraduate or graduate students in Europe.",
        residence: only(...EUROPE),
        educationLevels: only("undergraduate", "graduate"),
        enrollment: only("enrolled"),
      },
      value: { kind: "fixed", amount: 300, currency: "EUR" },
      deadlineType: "fixed",
      deadline: addDays(today, 28),
      officialUrl: site("lantern-housing-bursary"),
      sourceName: "Lantern Student Housing Trust",
      applicationInstructions:
        "Apply with your tenancy or accommodation booking and proof of enrollment.",
      ...verifiedDaysAgo(50),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.supplies,
      name: "Northlight Study Supplies Support",
      provider: "Northlight Education Fund",
      description: "A small payment toward books, stationery, and study supplies.",
      country: "GLOBAL",
      kind: "other",
      categories: ["learning_materials"],
      eligibility: { summary: "Open to students in any country." },
      value: { kind: "fixed", amount: 50, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 20),
      officialUrl: site("northlight-supplies"),
      sourceName: "Northlight Education Fund",
      applicationInstructions: "Submit a one-page request listing the supplies you need.",
      ...verifiedDaysAgo(70),
    }),

    /* ----- Added with the funding resource database ----- */

    demo({
      id: DEMO_RESOURCE_IDS.graduateStipend,
      name: "Kestrel Graduate Research Stipend",
      provider: "Kestrel Scholars Trust",
      description:
        "A variable stipend toward tuition and research materials for graduate and doctoral students.",
      country: "GLOBAL",
      kind: "grant",
      categories: ["tuition", "learning_materials"],
      eligibility: {
        summary:
          "Graduate and doctoral students in any country. The amount depends on the project.",
        educationLevels: only("graduate", "doctoral"),
        opportunityTypes: only("program", "scholarship"),
        additionalRequirements: ["A supervisor or department letter of support"],
      },
      value: { kind: "range", min: 500, max: 2000, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 55),
      officialUrl: site("kestrel-graduate-stipend"),
      sourceName: "Kestrel Scholars Trust",
      applicationInstructions:
        "Submit a one-page project summary and a supporter letter through the trust’s portal.",
      ...verifiedDaysAgo(30),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.baobabFund,
      name: "Baobab Learners Fund",
      provider: "Baobab Community Education Fund",
      description:
        "Support toward course fees and exam fees for learners in participating African countries.",
      country: "KE",
      kind: "grant",
      categories: ["tuition", "exam_fees"],
      eligibility: {
        summary: "Residents of participating African countries. Need-based.",
        residence: only(...AFRICA_DEMO),
        needBased: "yes",
      },
      value: { kind: "range", min: 150, max: 400, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 42),
      officialUrl: site("baobab-learners-fund"),
      sourceName: "Baobab Community Education Fund",
      applicationInstructions:
        "Apply through a participating community learning centre or the online form.",
      // Verified long ago: the engine and badges treat this as out of date.
      verification: "verified",
      lastVerifiedDate: addDays(today, -230),
      verificationNote: DEMO_NOTE,
    }),
    demo({
      id: DEMO_RESOURCE_IDS.digitalAccess,
      name: "Crescent Digital Access Programme",
      provider: "Crescent Learning Alliance",
      description: "Helps learners afford a laptop or tablet and a data plan for study.",
      country: "AE",
      kind: "grant",
      categories: ["technology"],
      eligibility: {
        summary: "Residents of the Gulf and South Asia in formal or vocational study. Need-based.",
        residence: only(...GULF_AND_SOUTH_ASIA),
        educationLevels: only("secondary", "vocational", "undergraduate", "graduate"),
        needBased: "yes",
      },
      value: { kind: "fixed", amount: 250, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, 38),
      officialUrl: site("crescent-digital-access"),
      sourceName: "Crescent Learning Alliance",
      applicationInstructions:
        "Apply online and attach a quote for the device. The grant is paid to the supplier.",
      ...verifiedDaysAgo(18),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.transitPass,
      name: "Pathfinder Student Transit Pass",
      provider: "Pathfinder Mobility Collective",
      description: "A subsidised monthly transit pass for students travelling to class.",
      country: "GLOBAL",
      kind: "other",
      categories: ["transportation"],
      eligibility: {
        summary: "Currently enrolled students. Whether it is need-based is not stated.",
        enrollment: only("enrolled"),
        needBased: "unknown",
      },
      value: { kind: "percent", percent: 40 },
      deadlineType: "rolling",
      officialUrl: site("pathfinder-transit-pass"),
      sourceName: "Pathfinder Mobility Collective",
      applicationInstructions: "Apply any time with your student card.",
      ...verifiedDaysAgo(120),
    }),
    demo({
      id: DEMO_RESOURCE_IDS.bootcampBursary,
      name: "Ember Coding Bootcamp Bursary",
      provider: "Ember Careers Initiative",
      description:
        "A bursary toward coding bootcamp fees. Most eligibility rules and the deadline have not been recorded yet.",
      country: "GLOBAL",
      kind: "grant",
      categories: ["tuition"],
      // Deliberately UNKNOWN: demonstrates that unknown is never treated as eligible.
      eligibility: {
        summary: "Eligibility details have not been confirmed.",
        residence: unknown,
        educationLevels: unknown,
        opportunityTypes: only("program", "course"),
        enrollment: unknown,
        needBased: "unknown",
      },
      value: { kind: "range", min: 200, max: 800, currency: "USD" },
      deadlineType: "unknown",
      officialUrl: site("ember-bootcamp-bursary"),
      sourceName: "Ember Careers Initiative",
      applicationInstructions: "Details not confirmed. Contact the provider before applying.",
      verification: "unverified",
    }),
    demo({
      id: DEMO_RESOURCE_IDS.retakeGrant,
      name: "Tidewater Exam Retake Grant",
      provider: "Tidewater Learning Fund",
      description: "A past grant toward exam retake fees. This listing has expired.",
      country: "GLOBAL",
      kind: "grant",
      categories: ["exam_fees"],
      eligibility: {
        summary: "Exam candidates retaking a certification exam.",
        opportunityTypes: only("exam"),
      },
      value: { kind: "fixed", amount: 120, currency: "USD" },
      deadlineType: "fixed",
      deadline: addDays(today, -15),
      officialUrl: site("tidewater-retake-grant"),
      sourceName: "Tidewater Learning Fund",
      applicationInstructions: "The application window has closed.",
      verification: "expired",
      lastVerifiedDate: addDays(today, -200),
      verificationNote: DEMO_NOTE,
    }),
  ];
}
