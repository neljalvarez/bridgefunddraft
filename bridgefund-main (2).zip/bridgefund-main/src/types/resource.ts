import type { BarrierCategory } from "./barrier";
import type { DateOnlyString, ID, ISODateString } from "./common";
import type {
  CurrencyCode,
  EducationLevel,
  EnrollmentStatus,
  FieldOfStudy,
  SupportResourceKind,
} from "./gap";
import type { OpportunityType } from "./opportunity";

/* -------------------------------------------------------------------------
 * Funding resource database.
 *
 * The central rule: UNKNOWN is a real value. A listing whose eligibility has
 * not been recorded is "unknown", never "open to everyone". Every eligibility
 * rule below is therefore a three-way `Criterion`, not an optional list.
 * ---------------------------------------------------------------------- */

/**
 * One eligibility rule.
 *  - any:     the provider places NO restriction on this (confirmed).
 *  - only:    restricted to the listed values.
 *  - unknown: nobody has recorded the rule. Matching must not assume it passes.
 */
export type Criterion<T extends string> =
  | { mode: "any" }
  | { mode: "only"; values: T[] }
  | { mode: "unknown" };

/** A yes/no rule that may also be unrecorded. */
export type TriState = "yes" | "no" | "unknown";

/* ------------------------------ Verification ------------------------------ */

export const RESOURCE_VERIFICATION_STATUSES = [
  "verified",
  "requires_reverification",
  "unverified",
  "expired",
] as const;
export type ResourceVerificationStatus =
  (typeof RESOURCE_VERIFICATION_STATUSES)[number];

/* --------------------------------- Value --------------------------------- */

export type ResourceValue =
  | { kind: "fixed"; amount: number; currency: CurrencyCode }
  /** A range. Planning always uses `min`, never `max`. */
  | { kind: "range"; min: number; max: number; currency: CurrencyCode }
  | { kind: "percent"; percent: number }
  | { kind: "full" };

/* ------------------------------- Eligibility ------------------------------ */

export interface ResourceEligibility {
  /** Plain-language summary shown to students. */
  summary: string;
  /** Country the STUDENT lives in (ISO codes). */
  residence: Criterion<string>;
  /** Country where the opportunity takes place (ISO codes). */
  studyCountries: Criterion<string>;
  educationLevels: Criterion<EducationLevel>;
  opportunityTypes: Criterion<OpportunityType>;
  fieldsOfStudy: Criterion<FieldOfStudy>;
  enrollment: Criterion<EnrollmentStatus>;
  /** Whether the provider tests financial need. */
  needBased: TriState;
  /**
   * Requirements BridgeFund cannot check from a student profile (for example
   * "first-generation student"). The matching engine always reports these as
   * unconfirmed and asks the student to check them with the provider.
   */
  additionalRequirements: string[];
}

/* ------------------------------- The resource ------------------------------ */

export type DeadlineType = "fixed" | "rolling" | "unknown";

export interface SupportResource {
  id: ID;
  name: string;
  provider: string;
  description: string;
  /** Country or region the program is based in: ISO code or "GLOBAL". */
  country: string;
  /** Type of support (grant, fee waiver, sponsorship, ...). */
  kind: SupportResourceKind;
  /** Expense categories this support can reduce. Empty means "not recorded". */
  categories: BarrierCategory[];
  eligibility: ResourceEligibility;
  value: ResourceValue;

  /** Required when `deadlineType` is "fixed". */
  deadline?: DateOnlyString;
  deadlineType: DeadlineType;

  /** Provider's official website (https). */
  officialUrl: string;
  /** Name shown for the official website. */
  sourceName: string;
  /** Direct application page, if different from the official website. */
  applicationUrl?: string;
  applicationInstructions: string;

  verification: ResourceVerificationStatus;
  /** When someone last confirmed the details against the provider's own source. */
  lastVerifiedDate?: DateOnlyString;
  /** The evidence behind the verification: what was checked, and where. */
  verificationNote?: string;

  /** True for fictional sample data. Shown everywhere as DEMO DATA. */
  isDemo: boolean;
  /** Set when an administrator archives the listing. Archived = hidden and never matched. */
  archivedAt?: ISODateString;
  createdAt?: ISODateString;
  updatedAt?: ISODateString;
}
