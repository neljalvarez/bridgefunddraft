import { Check, CircleDashed, Info, X } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import {
  MATCH_WEIGHTS,
  type CheckState,
  type MatchBand,
  type MatchEvaluation,
} from "@/lib/matching/engine";
import { cn } from "@/lib/utils";

const BAND_META: Record<MatchBand, { label: string; tone: "success" | "info" | "warning" | "danger" }> = {
  strong: { label: "Strong match", tone: "success" },
  good: { label: "Good match", tone: "info" },
  possible: { label: "Possible match", tone: "warning" },
  excluded: { label: "Not a match", tone: "danger" },
};

/** What "eligible" means here: the listing's published rules, never a guarantee. */
const STATUS_TEXT = {
  criteria_met: "Meets the listed criteria",
  needs_info: "Eligibility not confirmed",
  excluded: "Doesn’t meet a requirement",
} as const;

const STATE_ICON: Record<CheckState, typeof Check> = {
  pass: Check,
  unknown: CircleDashed,
  fail: X,
};
const STATE_STYLE: Record<CheckState, string> = {
  pass: "text-success",
  unknown: "text-warning-foreground",
  fail: "text-destructive-foreground",
};
const STATE_WORD: Record<CheckState, string> = {
  pass: "Passed",
  unknown: "Unconfirmed",
  fail: "Failed",
};

/** Compact "82 / 100" chip with band. */
export function ScoreBadge({ evaluation }: { evaluation: MatchEvaluation }) {
  const band = BAND_META[evaluation.band];
  return (
    <Badge tone={band.tone} title={`${STATUS_TEXT[evaluation.status]}. Relevance score ${evaluation.score} out of 100.`}>
      {band.label}
      {evaluation.status === "excluded" ? null : ` · ${evaluation.score}/100`}
    </Badge>
  );
}

interface MatchExplanationProps {
  evaluation: MatchEvaluation;
  /** Show the per-factor breakdown open by default. */
  defaultOpen?: boolean;
  className?: string;
}

/**
 * Why a listing was (or wasn't) recommended: score, what passed, what is
 * still unconfirmed, and the exact points each factor earned. Nothing here is
 * hidden; the numbers are the same ones the engine added up.
 */
export function MatchExplanation({ evaluation, defaultOpen, className }: MatchExplanationProps) {
  const excluded = evaluation.status === "excluded";
  const you = evaluation.missing.filter((m) => m.who === "you");
  const listing = evaluation.missing.filter((m) => m.who === "listing");

  return (
    <div className={cn("rounded-lg bg-muted/60 p-3 text-xs", className)}>
      <div className="flex flex-wrap items-center gap-2">
        <ScoreBadge evaluation={evaluation} />
        <span className="font-medium text-navy">{STATUS_TEXT[evaluation.status]}</span>
      </div>

      {excluded ? (
        <>
          <p className="mt-2 font-medium text-navy">Why it isn’t a match</p>
          <ul className="mt-1 space-y-0.5 text-muted-foreground">
            {evaluation.exclusions.map((reason) => (
              <li key={reason} className="before:mr-1.5 before:content-['•']">{reason}</li>
            ))}
          </ul>
        </>
      ) : (
        <>
          {evaluation.reasons.length > 0 ? (
            <>
              <p className="mt-2 font-medium text-navy">Why it was recommended</p>
              <ul className="mt-1 space-y-0.5 text-muted-foreground">
                {evaluation.reasons.map((reason) => (
                  <li key={reason} className="before:mr-1.5 before:content-['•']">{reason}</li>
                ))}
              </ul>
            </>
          ) : null}

          {evaluation.missing.length > 0 ? (
            <div className="mt-3 rounded-md border border-amber-200 bg-warning-soft p-2.5 text-warning-foreground">
              <p className="flex items-center gap-1.5 font-medium">
                <Info className="size-3.5" aria-hidden="true" />
                Missing information
              </p>
              <p className="mt-0.5">
                Unconfirmed items are never counted as eligible. Check them before you rely on this match.
              </p>
              {you.length > 0 ? (
                <ul className="mt-1.5 space-y-0.5">
                  {you.map((m, i) => (
                    <li key={`y${i}`} className="before:mr-1.5 before:content-['•']">
                      <span className="font-medium">From you:</span> {m.message}
                    </li>
                  ))}
                </ul>
              ) : null}
              {listing.length > 0 ? (
                <ul className="mt-1.5 space-y-0.5">
                  {listing.map((m, i) => (
                    <li key={`l${i}`} className="before:mr-1.5 before:content-['•']">
                      <span className="font-medium">From the listing:</span> {m.message}
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          ) : null}
        </>
      )}

      <details className="mt-3" open={defaultOpen}>
        <summary className="cursor-pointer select-none font-medium text-primary hover:underline">
          How the score was calculated
        </summary>
        <ul className="mt-2 space-y-2">
          {evaluation.factors.map((factor) => {
            const Icon = STATE_ICON[factor.state];
            return (
              <li key={factor.key}>
                <div className="flex items-center justify-between gap-3">
                  <span className="flex items-center gap-1.5 font-medium text-navy">
                    <Icon className={cn("size-3.5", STATE_STYLE[factor.state])} aria-hidden="true" />
                    {factor.label}
                    <span className="sr-only"> ({STATE_WORD[factor.state]})</span>
                  </span>
                  <span className="tabular-nums text-muted-foreground">
                    {excluded ? "n/a" : `${factor.points} / ${MATCH_WEIGHTS[factor.key]}`}
                  </span>
                </div>
                <ul className="mt-0.5 space-y-0.5 pl-5 text-muted-foreground">
                  {factor.checks.map((check, i) => (
                    <li key={i} className="before:mr-1.5 before:content-['–']">{check.detail}</li>
                  ))}
                </ul>
              </li>
            );
          })}
        </ul>
        {excluded ? (
          <p className="mt-2 text-muted-foreground">
            A failed requirement overrides the score, so this listing is excluded however the other factors scored.
          </p>
        ) : (
          <>
            {evaluation.caps.length > 0 ? (
              <ul className="mt-2 space-y-0.5 text-warning-foreground">
                {evaluation.caps.map((cap) => (
                  <li key={cap.reason}>
                    Capped at {cap.limit}: {cap.reason}
                  </li>
                ))}
              </ul>
            ) : null}
            <p className="mt-2 flex justify-between border-t border-border pt-2 font-medium text-navy">
              <span>Relevance score</span>
              <span className="tabular-nums">
                {evaluation.uncappedScore !== evaluation.score
                  ? `${evaluation.uncappedScore} → ${evaluation.score}`
                  : evaluation.score}{" "}
                / 100
              </span>
            </p>
          </>
        )}
      </details>
    </div>
  );
}
