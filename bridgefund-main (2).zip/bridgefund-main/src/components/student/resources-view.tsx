"use client";

import { Info, Plus, Search, SearchX } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";

import { EmptyState } from "@/components/shared/empty-state";
import { Field } from "@/components/shared/form-field";
import { PortalSkeleton } from "@/components/shared/portal-skeleton";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { COUNTRY_OPTIONS } from "@/config/countries";
import { RESOURCE_VERIFICATION_META } from "@/config/status";
import {
  DEADLINE_TYPE_LABELS,
  EDUCATION_LEVEL_LABELS,
  EXPENSE_CATEGORY_LABELS,
  RESOURCE_KIND_LABELS,
} from "@/config/option-labels";
import { useStudentPortal } from "@/hooks/use-student-portal";
import { createClaim } from "@/lib/gap/claims";
import { matchResourceToOpportunity, type Recommendation } from "@/lib/gap/matching";
import {
  DEFAULT_FILTERS,
  filterResources,
  hasActiveFilters,
  notArchived,
  SORT_LABELS,
  sortResources,
  type DeadlineFilter,
  type ResourceFilters,
  type ResourceSort,
} from "@/lib/resources/discovery";
import {
  BARRIER_CATEGORIES,
  EDUCATION_LEVELS,
  RESOURCE_KINDS,
  RESOURCE_VERIFICATION_STATUSES,
  type SupportResource,
} from "@/types";

import { ResourceCard } from "./resource-card";

const NO_OPPORTUNITY = "none";

const DEADLINE_FILTER_LABELS: Record<DeadlineFilter, string> = {
  all: "Any deadline",
  open: "Still open",
  closing_30: "Closing within 30 days",
  rolling: DEADLINE_TYPE_LABELS.rolling,
};

interface Row {
  resource: SupportResource;
  /** Best-scoring expense for the chosen opportunity, if any passes every hard rule. */
  best: Recommendation | null;
  /** The closest miss, shown to explain why nothing matched. */
  closest: Recommendation | null;
  evaluation: Recommendation["evaluation"] | null;
}

export function ResourcesView() {
  const portal = useStudentPortal();
  const [filters, setFilters] = useState<ResourceFilters>(DEFAULT_FILTERS);
  const [sortChoice, setSortChoice] = useState<ResourceSort>("relevance");
  const [opportunityChoice, setOpportunityChoice] = useState<string | null>(null);
  const [onlyMatches, setOnlyMatches] = useState(true);

  const data = portal?.data;
  const today = portal?.today;
  const resources = portal?.resources;

  const opportunities = useMemo(
    () => (data ? data.opportunities.filter((o) => o.status !== "archived" && o.expenses.length > 0) : []),
    [data],
  );
  const opportunity =
    opportunityChoice === NO_OPPORTUNITY
      ? null
      : (opportunities.find((o) => o.id === opportunityChoice) ?? opportunities[0] ?? null);

  const rows: Row[] = useMemo(() => {
    if (!data || !today || !resources) return [];
    const filtered = filterResources(resources.filter(notArchived), filters, today);
    const built = filtered.map<Row>((resource) => {
      if (!opportunity) return { resource, best: null, closest: null, evaluation: null };
      const { best, perExpense } = matchResourceToOpportunity(resource, opportunity, data.profile, today);
      const closest =
        best ??
        [...perExpense].sort((a, b) => a.evaluation.exclusions.length - b.evaluation.exclusions.length)[0] ??
        null;
      return { resource, best, closest, evaluation: (best ?? closest)?.evaluation ?? null };
    });
    const visible = opportunity && onlyMatches ? built.filter((r) => r.best) : built;
    return sortResources(
      visible.map((r) => ({ ...r, evaluation: r.best?.evaluation ?? null })),
      opportunity ? sortChoice : sortChoice === "relevance" ? "name" : sortChoice,
      today,
    );
  }, [data, today, resources, filters, opportunity, onlyMatches, sortChoice]);

  if (!portal || !data || !today || !resources) return <PortalSkeleton />;
  const { actions } = portal;
  const set = <K extends keyof ResourceFilters>(key: K, value: ResourceFilters[K]) =>
    setFilters((f) => ({ ...f, [key]: value }));

  const addToPlan = (rec: Recommendation) => {
    if (!opportunity) return;
    const exists = opportunity.claims.some(
      (c) => c.resourceId === rec.resource.id && c.expenseId === rec.expenseId,
    );
    if (exists) return;
    actions.upsertOpportunity({ ...opportunity, claims: [...opportunity.claims, createClaim(rec)] });
  };
  const removeFromPlan = (claimId: string) => {
    if (!opportunity) return;
    actions.upsertOpportunity({
      ...opportunity,
      claims: opportunity.claims.filter((c) => c.id !== claimId),
    });
  };

  const profileIncomplete = !data.profile.residenceCountry || !data.profile.educationLevel;
  const total = resources.filter(notArchived).length;

  return (
    <div className="space-y-6">
      {/* Which opportunity to score against */}
      <section
        aria-labelledby="match-context"
        className="rounded-xl border border-border bg-card p-5"
      >
        <h2 id="match-context" className="text-sm font-semibold text-navy">
          Match against your opportunity
        </h2>
        {opportunities.length === 0 ? (
          <p className="mt-1 text-sm text-muted-foreground">
            Match scores come from your real expenses.{" "}
            <Link href="/student/resolver" className="font-medium text-primary hover:underline">
              Add an opportunity and its costs in the Gap Resolver
            </Link>{" "}
            to see how well each listing fits. Until then you can still search and filter.
          </p>
        ) : (
          <div className="mt-3 flex flex-col gap-4 sm:flex-row sm:items-end">
            <Field id="res-opportunity" label="Opportunity" className="sm:w-96">
              <Select
                id="res-opportunity"
                value={opportunity?.id ?? NO_OPPORTUNITY}
                onChange={(e) => setOpportunityChoice(e.target.value)}
              >
                {opportunities.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.title || "Untitled opportunity"}
                  </option>
                ))}
                <option value={NO_OPPORTUNITY}>None (browse all listings)</option>
              </Select>
            </Field>
            {opportunity ? (
              <div className="flex items-center gap-2 pb-2.5">
                <Checkbox
                  id="res-only-matches"
                  checked={onlyMatches}
                  onChange={(e) => setOnlyMatches(e.target.checked)}
                />
                <Label htmlFor="res-only-matches">Only listings that fit one of its expenses</Label>
              </div>
            ) : null}
          </div>
        )}
        {opportunity && profileIncomplete ? (
          <p className="mt-3 flex gap-2 rounded-lg border border-amber-200 bg-warning-soft p-3 text-sm text-warning-foreground">
            <Info className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            <span>
              Your country or education level isn’t set, so listings that depend on them show as unconfirmed rather
              than eligible.{" "}
              <Link href="/student/settings" className="font-medium underline">
                Complete your details
              </Link>
              .
            </span>
          </p>
        ) : null}
      </section>

      {/* Search + filters */}
      <section aria-label="Search and filters" className="space-y-4 rounded-xl border border-border bg-card p-5">
        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            type="search"
            aria-label="Search funding listings"
            placeholder="Search by name, provider, cost, or country"
            value={filters.query}
            onChange={(e) => set("query", e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field id="f-kind" label="Type of support">
            <Select id="f-kind" value={filters.kind} onChange={(e) => set("kind", e.target.value as ResourceFilters["kind"])}>
              <option value="all">All types</option>
              {RESOURCE_KINDS.map((k) => (
                <option key={k} value={k}>{RESOURCE_KIND_LABELS[k]}</option>
              ))}
            </Select>
          </Field>
          <Field id="f-category" label="Expense it covers">
            <Select id="f-category" value={filters.category} onChange={(e) => set("category", e.target.value as ResourceFilters["category"])}>
              <option value="all">Any expense</option>
              {BARRIER_CATEGORIES.map((c) => (
                <option key={c} value={c}>{EXPENSE_CATEGORY_LABELS[c]}</option>
              ))}
            </Select>
          </Field>
          <Field id="f-country" label="Open to residents of">
            <Select id="f-country" value={filters.country} onChange={(e) => set("country", e.target.value)}>
              <option value="all">Any country</option>
              {COUNTRY_OPTIONS.filter((c) => c.code !== "OTHER").map((c) => (
                <option key={c.code} value={c.code}>{c.name}</option>
              ))}
            </Select>
          </Field>
          <Field id="f-education" label="Education level">
            <Select id="f-education" value={filters.education} onChange={(e) => set("education", e.target.value as ResourceFilters["education"])}>
              <option value="all">Any level</option>
              {EDUCATION_LEVELS.map((l) => (
                <option key={l} value={l}>{EDUCATION_LEVEL_LABELS[l]}</option>
              ))}
            </Select>
          </Field>
          <Field id="f-deadline" label="Deadline">
            <Select id="f-deadline" value={filters.deadline} onChange={(e) => set("deadline", e.target.value as DeadlineFilter)}>
              {(Object.keys(DEADLINE_FILTER_LABELS) as DeadlineFilter[]).map((d) => (
                <option key={d} value={d}>{DEADLINE_FILTER_LABELS[d]}</option>
              ))}
            </Select>
          </Field>
          <Field id="f-verification" label="Verification">
            <Select id="f-verification" value={filters.verification} onChange={(e) => set("verification", e.target.value as ResourceFilters["verification"])}>
              <option value="all">Any status</option>
              {RESOURCE_VERIFICATION_STATUSES.map((v) => (
                <option key={v} value={v}>{RESOURCE_VERIFICATION_META[v].label}</option>
              ))}
            </Select>
          </Field>
          <Field id="f-sort" label="Sort by">
            <Select
              id="f-sort"
              value={opportunity ? sortChoice : sortChoice === "relevance" ? "name" : sortChoice}
              onChange={(e) => setSortChoice(e.target.value as ResourceSort)}
            >
              {(Object.keys(SORT_LABELS) as ResourceSort[]).map((s) => (
                <option key={s} value={s} disabled={s === "relevance" && !opportunity}>
                  {SORT_LABELS[s]}
                  {s === "relevance" && !opportunity ? " (choose an opportunity)" : ""}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
          <div className="flex items-center gap-2">
            <Checkbox id="f-unknown" checked={filters.includeUnknown} onChange={(e) => set("includeUnknown", e.target.checked)} />
            <Label htmlFor="f-unknown">Include listings whose eligibility is unknown</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox id="f-expired" checked={filters.includeExpired} onChange={(e) => set("includeExpired", e.target.checked)} />
            <Label htmlFor="f-expired">Include expired listings</Label>
          </div>
          {hasActiveFilters(filters) ? (
            <Button variant="link" size="sm" className="h-auto p-0" onClick={() => setFilters(DEFAULT_FILTERS)}>
              Clear filters
            </Button>
          ) : null}
        </div>
      </section>

      <p role="status" aria-live="polite" className="text-sm text-muted-foreground">
        Showing {rows.length} of {total} listing{total === 1 ? "" : "s"}.{" "}
        <span className="text-xs">
          Listings are not guarantees of funding; providers decide who receives support.
        </span>
      </p>

      {rows.length === 0 ? (
        <EmptyState
          icon={SearchX}
          title="No listings found"
          description={
            opportunity && onlyMatches
              ? "No listing fits an expense of this opportunity with these filters. Clear a filter, or show all listings."
              : "Nothing matches these filters. Try removing one."
          }
          action={
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button variant="outline" onClick={() => setFilters(DEFAULT_FILTERS)}>
                Clear filters
              </Button>
              {opportunity && onlyMatches ? (
                <Button variant="outline" onClick={() => setOnlyMatches(false)}>
                  Show all listings
                </Button>
              ) : null}
            </div>
          }
        />
      ) : (
        <ul className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          {rows.map(({ resource, best, closest }) => {
            const rec = best ?? closest;
            const expense = rec ? opportunity?.expenses.find((e) => e.id === rec.expenseId) : undefined;
            return (
              <li key={resource.id}>
                <ResourceCard
                  resource={resource}
                  today={today}
                  evaluation={rec?.evaluation}
                  forExpense={expense?.name}
                  value={best && expense ? { amount: best.claim?.amount ?? best.value, currency: expense.currency } : undefined}
                  saved={data.savedResourceIds.includes(resource.id)}
                  onToggleSave={() => actions.toggleSavedResource(resource.id)}
                  planStatus={best?.claim?.status ?? null}
                  onAdd={best ? () => addToPlan(best) : undefined}
                  onRemove={best?.claim ? () => removeFromPlan(best.claim!.id) : undefined}
                />
              </li>
            );
          })}
        </ul>
      )}

      {opportunity ? (
        <p className="text-sm text-muted-foreground">
          Plan items you add here appear in{" "}
          <Link href={`/student/resolver?opportunity=${opportunity.id}&step=5`} className="font-medium text-primary hover:underline">
            the Gap Resolver
          </Link>{" "}
          and{" "}
          <Link href="/student/matches" className="font-medium text-primary hover:underline">
            Funding Matches
          </Link>
          , but nothing counts as funding until a provider approves it.
        </p>
      ) : (
        <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Plus className="size-4" aria-hidden="true" />
          Choose an opportunity above to add listings to your plan.
        </p>
      )}
    </div>
  );
}
