import { Bookmark, BookmarkCheck, CalendarClock, ExternalLink, Plus, X } from "lucide-react";
import Link from "next/link";

import { StatusBadge } from "@/components/shared/status-badge";
import { DemoBadge, VerificationBadge } from "@/components/shared/verification-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getCountryName } from "@/config/countries";
import { CLAIM_STATUS_META } from "@/config/status";
import { RESOURCE_KIND_META } from "@/config/student-options";
import { formatCurrency } from "@/lib/currency";
import { daysBetween, describeDaysLeft } from "@/lib/dates";
import { formatDay } from "@/lib/format";
import { describeValue } from "@/lib/gap/matching";
import type { MatchEvaluation } from "@/lib/matching/engine";
import { isHttpsUrl } from "@/lib/resources/validation";
import { effectiveVerification } from "@/lib/resources/verification";
import { cn } from "@/lib/utils";
import type { ClaimStatus, CurrencyCode, DateOnlyString, SupportResource } from "@/types";

import { MatchExplanation, ScoreBadge } from "./match-explanation";

interface ResourceCardProps {
  resource: SupportResource;
  today: DateOnlyString;
  /** Potential value for the expense this is matched to. */
  value?: { amount: number; currency: CurrencyCode };
  /** Plain reasons it matched. Ignored when `evaluation` is given. */
  reasons?: string[];
  /** The explainable score for this listing against the student's expense. */
  evaluation?: MatchEvaluation;
  /** Name of the expense this match is for, shown with the score. */
  forExpense?: string;
  saved: boolean;
  onToggleSave: () => void;
  /** Plan state for this resource + expense; null/undefined when not in the plan. */
  planStatus?: ClaimStatus | null;
  onAdd?: () => void;
  onRemove?: () => void;
  /** Hide the link to the details page (used on the details page itself). */
  hideDetailsLink?: boolean;
}

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-medium text-muted-foreground">{label}</dt>
      <dd className="mt-0.5 text-sm text-foreground">{children}</dd>
    </div>
  );
}

/** Deadline text for a listing: fixed, rolling, or not recorded. */
export function DeadlineText({ resource, today }: { resource: SupportResource; today: DateOnlyString }) {
  if (resource.deadlineType === "fixed" && resource.deadline) {
    const days = daysBetween(today, resource.deadline);
    return (
      <span className={cn("inline-flex items-center gap-1.5", days >= 0 && days <= 7 && "font-medium text-warning-foreground")}>
        <CalendarClock className="size-3.5" aria-hidden="true" />
        {formatDay(resource.deadline)} · {days < 0 ? "Closed" : describeDaysLeft(days)}
      </span>
    );
  }
  if (resource.deadlineType === "rolling") return <>Rolling, no fixed deadline</>;
  return <span className="text-warning-foreground">Not recorded. Ask the provider.</span>;
}

/** The link a student follows to apply: the application page, else the official site. */
export function applyHref(resource: SupportResource): string | null {
  const href = resource.applicationUrl || resource.officialUrl;
  return isHttpsUrl(href) ? href : null;
}

export function ResourceCard({
  resource,
  today,
  value,
  reasons,
  evaluation,
  forExpense,
  saved,
  onToggleSave,
  planStatus,
  onAdd,
  onRemove,
  hideDetailsLink,
}: ResourceCardProps) {
  const kind = RESOURCE_KIND_META[resource.kind];
  const KindIcon = kind.icon;
  const status = effectiveVerification(resource, today);
  const archived = !!resource.archivedAt;
  const closed = archived || status === "expired";
  const inPlan = planStatus != null;
  const removable = inPlan && (planStatus === "planned" || planStatus === "applied" || planStatus === "declined");
  const apply = closed ? null : applyHref(resource);
  const excluded = evaluation?.status === "excluded";

  return (
    <Card className={cn("p-5", closed && "opacity-80")}>
      <div className="flex items-start gap-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-accent text-primary">
          <KindIcon className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <h4 className="text-sm font-semibold text-navy">
            {hideDetailsLink ? (
              resource.name
            ) : (
              <Link href={`/student/resources/${resource.id}`} className="hover:underline">
                {resource.name}
              </Link>
            )}
          </h4>
          <p className="text-xs text-muted-foreground">{resource.provider}</p>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <Badge tone="info">{kind.label}</Badge>
            <VerificationBadge resource={resource} today={today} />
            {resource.isDemo ? <DemoBadge /> : null}
            {archived ? <Badge tone="neutral">Archived</Badge> : null}
            {evaluation ? <ScoreBadge evaluation={evaluation} /> : null}
            {inPlan ? <StatusBadge meta={CLAIM_STATUS_META[planStatus]} /> : null}
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="-mr-2 -mt-1 shrink-0"
          onClick={onToggleSave}
          aria-pressed={saved}
          aria-label={saved ? `Remove ${resource.name} from saved resources` : `Save ${resource.name}`}
        >
          {saved ? <BookmarkCheck className="text-primary" /> : <Bookmark />}
        </Button>
      </div>

      <p className="mt-3 text-sm text-muted-foreground">{resource.description}</p>

      <dl className="mt-4 grid gap-4 sm:grid-cols-2">
        <Fact label={kind.selfDirected ? "Estimated saving" : value ? "Potential value, if approved" : "Assistance"}>
          <span className="font-semibold text-navy">
            {value ? formatCurrency(value.amount, value.currency) : describeValue(resource)}
          </span>
          {value ? <span className="text-muted-foreground"> · {describeValue(resource)}</span> : null}
          {resource.value.kind === "range" ? (
            <span className="block text-xs text-muted-foreground">Plans use the minimum, never the maximum.</span>
          ) : null}
        </Fact>
        <Fact label="Application deadline">
          <DeadlineText resource={resource} today={today} />
        </Fact>
        <Fact label="Eligibility">{resource.eligibility.summary}</Fact>
        <Fact label="Official website">
          {isHttpsUrl(resource.officialUrl) ? (
            <a
              href={resource.officialUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
            >
              {resource.sourceName || resource.provider}
              <ExternalLink className="size-3.5" aria-hidden="true" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          ) : (
            <span className="text-muted-foreground">No valid link recorded</span>
          )}
          <span className="block text-xs text-muted-foreground">
            {resource.country === "GLOBAL" ? "Global" : getCountryName(resource.country)}
            {resource.isDemo ? " · Fictional demo link" : ""}
          </span>
        </Fact>
      </dl>

      {evaluation ? (
        <div className="mt-4">
          {forExpense ? (
            <p className="mb-1.5 text-xs text-muted-foreground">
              Scored against: <span className="font-medium text-navy">{forExpense}</span>
            </p>
          ) : null}
          <MatchExplanation evaluation={evaluation} />
        </div>
      ) : reasons && reasons.length > 0 ? (
        <div className="mt-4 rounded-lg bg-muted/60 p-3">
          <p className="text-xs font-medium text-navy">Why it fits you</p>
          <ul className="mt-1.5 space-y-0.5 text-xs text-muted-foreground">
            {reasons.map((reason) => (
              <li key={reason} className="before:mr-1.5 before:content-['•']">{reason}</li>
            ))}
          </ul>
        </div>
      ) : null}

      {!evaluation && (status === "unverified" || status === "requires_reverification") ? (
        <p className="mt-3 text-xs text-warning-foreground">
          {status === "unverified" ? "Not yet verified." : "Verification is out of date."} Confirm the details with
          the provider before you apply.
        </p>
      ) : null}
      {closed ? (
        <p className="mt-3 text-xs text-muted-foreground">
          {archived ? "This listing has been archived." : "This listing has expired."} It is shown only because you saved it.
        </p>
      ) : null}

      <div className="mt-4 flex flex-wrap items-center gap-3">
        {onAdd || onRemove ? (
          inPlan ? (
            removable && onRemove ? (
              <Button variant="outline" size="sm" onClick={onRemove}>
                <X /> Remove from plan
              </Button>
            ) : (
              <p className="text-xs text-muted-foreground">In your plan. Update its status under Applications.</p>
            )
          ) : onAdd && !excluded ? (
            <Button size="sm" onClick={onAdd}>
              <Plus /> Add to my plan
            </Button>
          ) : null
        ) : null}
        {apply && !excluded ? (
          <Button asChild variant="outline" size="sm">
            <a href={apply} target="_blank" rel="noopener noreferrer">
              Apply on provider site <ExternalLink />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          </Button>
        ) : null}
        {hideDetailsLink ? null : (
          <Button asChild variant="link" size="sm" className="ml-auto px-0">
            <Link href={`/student/resources/${resource.id}`}>View details</Link>
          </Button>
        )}
      </div>
    </Card>
  );
}
