"use client";

import { ArrowLeft, Bookmark, BookmarkCheck, ExternalLink, SearchX } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

import { EmptyState } from "@/components/shared/empty-state";
import { Field } from "@/components/shared/form-field";
import { PortalSkeleton } from "@/components/shared/portal-skeleton";
import { DemoBadge, VerificationBadge } from "@/components/shared/verification-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { getCountryName } from "@/config/countries";
import {
  DEADLINE_TYPE_LABELS,
  EDUCATION_LEVEL_LABELS,
  ENROLLMENT_LABELS,
  EXPENSE_CATEGORY_LABELS,
  FIELD_OF_STUDY_LABELS,
  OPPORTUNITY_TYPE_LABELS,
} from "@/config/option-labels";
import { RESOURCE_VERIFICATION_META } from "@/config/status";
import { RESOURCE_KIND_META } from "@/config/student-options";
import { useStudentPortal } from "@/hooks/use-student-portal";
import { formatDay } from "@/lib/format";
import { createClaim } from "@/lib/gap/claims";
import { describeValue, matchResourceToOpportunity, type Recommendation } from "@/lib/gap/matching";
import { effectiveVerification } from "@/lib/resources/verification";
import { isHttpsUrl } from "@/lib/resources/validation";
import { formatCurrency } from "@/lib/currency";
import type { Criterion } from "@/types";

import { MatchExplanation } from "./match-explanation";
import { applyHref, DeadlineText } from "./resource-card";

function describeCriterion<T extends string>(c: Criterion<T>, label: (v: T) => string, anyText: string): string {
  if (c.mode === "any") return anyText;
  if (c.mode === "unknown" || c.values.length === 0) return "Unknown: not recorded for this listing";
  return c.values.map(label).join(", ");
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1 py-3 sm:grid-cols-3 sm:gap-4">
      <dt className="text-sm font-medium text-muted-foreground">{label}</dt>
      <dd className="text-sm text-foreground sm:col-span-2">{children}</dd>
    </div>
  );
}

export function ResourceDetailView({ id }: { id: string }) {
  const portal = useStudentPortal();
  const [choice, setChoice] = useState<string | null>(null);
  if (!portal) return <PortalSkeleton />;
  const { data, today, resources, actions } = portal;

  const resource = resources.find((r) => r.id === id);
  const saved = data.savedResourceIds.includes(id);
  const back = (
    <Button asChild variant="ghost" size="sm" className="-ml-3 mb-4">
      <Link href="/student/resources">
        <ArrowLeft /> All funding listings
      </Link>
    </Button>
  );

  // Archived listings are hidden from students unless they saved them.
  if (!resource || (resource.archivedAt && !saved)) {
    return (
      <>
        {back}
        <EmptyState
          icon={SearchX}
          title="Listing not found"
          description="This listing may have been removed or archived."
          action={<Button asChild><Link href="/student/resources">Browse listings</Link></Button>}
        />
      </>
    );
  }

  const e = resource.eligibility;
  const kind = RESOURCE_KIND_META[resource.kind];
  const status = effectiveVerification(resource, today);
  const closed = !!resource.archivedAt || status === "expired";
  const apply = closed ? null : applyHref(resource);

  const opportunities = data.opportunities.filter((o) => o.status !== "archived" && o.expenses.length > 0);
  const opportunity = opportunities.find((o) => o.id === choice) ?? opportunities[0] ?? null;
  const match = opportunity ? matchResourceToOpportunity(resource, opportunity, data.profile, today) : null;

  const addToPlan = (rec: Recommendation) => {
    if (!opportunity) return;
    if (opportunity.claims.some((c) => c.resourceId === rec.resource.id && c.expenseId === rec.expenseId)) return;
    actions.upsertOpportunity({ ...opportunity, claims: [...opportunity.claims, createClaim(rec)] });
  };
  const removeFromPlan = (claimId: string) => {
    if (!opportunity) return;
    actions.upsertOpportunity({ ...opportunity, claims: opportunity.claims.filter((c) => c.id !== claimId) });
  };

  return (
    <div className="space-y-6">
      {back}

      <Card className="shadow-none">
        <CardContent className="space-y-4 pt-6">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-semibold text-navy">{resource.name}</h2>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{resource.provider}</p>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Badge tone="info">{kind.label}</Badge>
                <VerificationBadge resource={resource} today={today} showDate />
                {resource.isDemo ? <DemoBadge /> : null}
                {resource.archivedAt ? <Badge tone="neutral">Archived</Badge> : null}
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => actions.toggleSavedResource(resource.id)}
              aria-pressed={saved}
            >
              {saved ? <BookmarkCheck className="text-primary" /> : <Bookmark />}
              {saved ? "Saved" : "Save"}
            </Button>
          </div>

          <p className="text-sm text-foreground">{resource.description}</p>

          {resource.isDemo ? (
            <p className="rounded-lg border border-amber-200 bg-warning-soft p-3 text-sm text-warning-foreground">
              <strong>DEMO DATA.</strong> This is a fictional sample listing. It is not a real funding program, and
              nothing here means funding exists.
            </p>
          ) : null}
          {!resource.isDemo && status !== "verified" ? (
            <p className="rounded-lg border border-amber-200 bg-warning-soft p-3 text-sm text-warning-foreground">
              {RESOURCE_VERIFICATION_META[status].description} Confirm details on the provider’s site before you apply.
            </p>
          ) : null}

          <div className="flex flex-wrap gap-3">
            {apply ? (
              <Button asChild>
                <a href={apply} target="_blank" rel="noopener noreferrer">
                  Apply on provider site <ExternalLink />
                  <span className="sr-only">(opens in a new tab)</span>
                </a>
              </Button>
            ) : null}
            {isHttpsUrl(resource.officialUrl) ? (
              <Button asChild variant="outline">
                <a href={resource.officialUrl} target="_blank" rel="noopener noreferrer">
                  Official website <ExternalLink />
                  <span className="sr-only">(opens in a new tab)</span>
                </a>
              </Button>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Details</CardTitle>
        </CardHeader>
        <CardContent>
          <dl className="divide-y divide-border">
            <Row label="Assistance">
              <span className="font-semibold text-navy">{describeValue(resource)}</span>
              {resource.value.kind === "range" ? (
                <span className="block text-xs text-muted-foreground">Plans use the minimum, never the maximum.</span>
              ) : null}
            </Row>
            <Row label="Support type">{kind.label}: {kind.description}</Row>
            <Row label="Country">{resource.country === "GLOBAL" ? "Global" : getCountryName(resource.country)}</Row>
            <Row label="Expenses covered">
              {resource.categories.length > 0
                ? resource.categories.map((c) => EXPENSE_CATEGORY_LABELS[c]).join(", ")
                : "Unknown: not recorded for this listing"}
            </Row>
            <Row label="Deadline">
              <DeadlineText resource={resource} today={today} />
              <span className="block text-xs text-muted-foreground">{DEADLINE_TYPE_LABELS[resource.deadlineType]}</span>
            </Row>
            <Row label="How to apply">{resource.applicationInstructions || "Not recorded."}</Row>
          </dl>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Eligibility requirements</CardTitle>
          <CardDescription>{e.summary}</CardDescription>
        </CardHeader>
        <CardContent>
          <dl className="divide-y divide-border">
            <Row label="Residence">{describeCriterion(e.residence, getCountryName, "Any country")}</Row>
            <Row label="Study location">{describeCriterion(e.studyCountries, getCountryName, "Any country")}</Row>
            <Row label="Education levels">{describeCriterion(e.educationLevels, (v) => EDUCATION_LEVEL_LABELS[v], "Any level")}</Row>
            <Row label="Opportunity types">{describeCriterion(e.opportunityTypes, (v) => OPPORTUNITY_TYPE_LABELS[v], "Any type")}</Row>
            <Row label="Field of study">{describeCriterion(e.fieldsOfStudy, (v) => FIELD_OF_STUDY_LABELS[v], "Any field")}</Row>
            <Row label="Enrollment">{describeCriterion(e.enrollment, (v) => ENROLLMENT_LABELS[v], "Any status")}</Row>
            <Row label="Financial need">
              {e.needBased === "yes" ? "Need-based" : e.needBased === "no" ? "No need test" : "Unknown: not recorded for this listing"}
            </Row>
            {e.additionalRequirements.length > 0 ? (
              <Row label="Also required">
                <ul className="list-disc space-y-0.5 pl-4">
                  {e.additionalRequirements.map((r) => <li key={r}>{r}</li>)}
                </ul>
              </Row>
            ) : null}
          </dl>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Verification</CardTitle>
        </CardHeader>
        <CardContent>
          <dl className="divide-y divide-border">
            <Row label="Status"><VerificationBadge resource={resource} today={today} /></Row>
            <Row label="Meaning">{RESOURCE_VERIFICATION_META[status].description}</Row>
            <Row label="Last verified">
              {resource.lastVerifiedDate ? formatDay(resource.lastVerifiedDate) : "Never verified"}
            </Row>
            {resource.verificationNote ? <Row label="Evidence">{resource.verificationNote}</Row> : null}
          </dl>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>How it fits your opportunity</CardTitle>
          <CardDescription>Scored against each expense you entered in the Gap Resolver.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!opportunity || !match ? (
            <p className="text-sm text-muted-foreground">
              Add an opportunity and its costs to see how this listing fits.{" "}
              <Link href="/student/resolver" className="font-medium text-primary hover:underline">Open the Gap Resolver</Link>
            </p>
          ) : (
            <>
              <Field id="detail-opportunity" label="Opportunity" className="sm:w-96">
                <Select id="detail-opportunity" value={opportunity.id} onChange={(ev) => setChoice(ev.target.value)}>
                  {opportunities.map((o) => (
                    <option key={o.id} value={o.id}>{o.title || "Untitled opportunity"}</option>
                  ))}
                </Select>
              </Field>
              <ul className="space-y-4">
                {match.perExpense.map((rec) => {
                  const expense = opportunity.expenses.find((x) => x.id === rec.expenseId);
                  if (!expense) return null;
                  const excluded = rec.evaluation.status === "excluded";
                  return (
                    <li key={rec.expenseId} className="rounded-lg border border-border p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="text-sm font-medium text-navy">
                          {expense.name}{" "}
                          <span className="font-normal text-muted-foreground">
                            · {formatCurrency(expense.amount, expense.currency)}
                          </span>
                        </p>
                        {!excluded && !closed ? (
                          rec.claim ? (
                            rec.claim.status === "planned" || rec.claim.status === "applied" || rec.claim.status === "declined" ? (
                              <Button variant="outline" size="sm" onClick={() => removeFromPlan(rec.claim!.id)}>Remove from plan</Button>
                            ) : (
                              <span className="text-xs text-muted-foreground">In your plan</span>
                            )
                          ) : (
                            <Button size="sm" onClick={() => addToPlan(rec)}>
                              Add to plan · {formatCurrency(rec.value, expense.currency)} potential
                            </Button>
                          )
                        ) : null}
                      </div>
                      <MatchExplanation evaluation={rec.evaluation} className="mt-3" />
                    </li>
                  );
                })}
              </ul>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
