import { Ban, ShieldAlert, ShieldCheck } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { RESOURCE_VERIFICATION_META } from "@/config/status";
import { formatDay } from "@/lib/format";
import { effectiveVerification } from "@/lib/resources/verification";
import type { DateOnlyString, SupportResource } from "@/types";

const ICONS = {
  verified: ShieldCheck,
  requires_reverification: ShieldAlert,
  unverified: ShieldAlert,
  expired: Ban,
} as const;

interface VerificationBadgeProps {
  resource: Pick<
    SupportResource,
    "verification" | "lastVerifiedDate" | "deadline" | "deadlineType"
  >;
  today: DateOnlyString;
  /** Also show "Last verified …" beside the badge. */
  showDate?: boolean;
}

/**
 * The verification badge students see everywhere. It shows the EFFECTIVE
 * status: a "verified" listing whose evidence is out of date, or whose
 * deadline has passed, is shown as such rather than as Verified.
 */
export function VerificationBadge({ resource, today, showDate }: VerificationBadgeProps) {
  const status = effectiveVerification(resource, today);
  const meta = RESOURCE_VERIFICATION_META[status];
  const Icon = ICONS[status];
  const date = resource.lastVerifiedDate
    ? `Last verified ${formatDay(resource.lastVerifiedDate)}`
    : "Never verified";

  return (
    <span className="inline-flex flex-wrap items-center gap-1.5">
      <Badge tone={meta.tone} title={`${meta.description} ${date}.`}>
        <Icon className="size-3" aria-hidden="true" />
        {meta.label}
      </Badge>
      {showDate ? <span className="text-xs text-muted-foreground">{date}</span> : null}
    </span>
  );
}

/** Every fictional listing carries this badge. */
export function DemoBadge() {
  return (
    <Badge
      tone="warning"
      className="uppercase tracking-wide"
      title="Fictional sample listing. It is not a real funding program."
    >
      Demo data
    </Badge>
  );
}
