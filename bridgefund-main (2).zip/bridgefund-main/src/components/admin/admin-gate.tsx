"use client";

import { ShieldAlert, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";

import { EmptyState } from "@/components/shared/empty-state";
import { PortalSkeleton } from "@/components/shared/portal-skeleton";
import { Button } from "@/components/ui/button";
import { isSupabaseConfigured } from "@/lib/env";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

type GateState = "checking" | "allowed" | "signed_out" | "forbidden" | "not_configured" | "demo";

/** Local demo mode exists only in development builds, never in production. */
const DEMO_ADMIN_AVAILABLE = process.env.NODE_ENV !== "production";

/**
 * Only administrators may manage funding resources.
 *
 * With Supabase connected, access requires `app_metadata.role === "admin"`.
 * `app_metadata` can only be written with the service role, unlike
 * `user_metadata`, which users can edit themselves.
 *
 * This is a UI gate. It hides the tools; it cannot protect data. The real
 * boundary must be Row Level Security on the resources table (and a server
 * check) once the catalog moves out of browser storage; see the README.
 */
export function AdminGate({ children }: { children: ReactNode }) {
  const [state, setState] = useState<GateState>(
    isSupabaseConfigured ? "checking" : "not_configured",
  );

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    let cancelled = false;
    createSupabaseBrowserClient()
      .auth.getUser()
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error || !data.user) return setState("signed_out");
        setState(data.user.app_metadata?.role === "admin" ? "allowed" : "forbidden");
      })
      .catch(() => {
        if (!cancelled) setState("signed_out");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (state === "checking") return <PortalSkeleton />;

  if (state === "allowed" || state === "demo") {
    return (
      <>
        {state === "demo" ? (
          <p
            role="note"
            className="mb-6 rounded-lg border border-amber-200 bg-warning-soft p-3 text-sm text-warning-foreground"
          >
            <strong>Local demo admin mode.</strong> This is not real authentication. Anyone using this browser can
            edit the catalog, and edits are stored only in this browser. Connect Supabase and sign in as an
            administrator for real access control.
          </p>
        ) : null}
        {children}
      </>
    );
  }

  if (state === "not_configured") {
    return (
      <EmptyState
        icon={ShieldAlert}
        title="Administrator sign-in isn’t available yet"
        description="Funding resources can only be managed by signed-in administrators, and BridgeFund isn’t connected to Supabase yet. See the README to connect it."
        action={
          DEMO_ADMIN_AVAILABLE ? (
            <Button variant="outline" onClick={() => setState("demo")}>
              <ShieldCheck /> Continue in local demo admin mode
            </Button>
          ) : undefined
        }
      />
    );
  }

  if (state === "signed_out") {
    return (
      <EmptyState
        icon={ShieldAlert}
        title="Sign in as an administrator"
        description="You need to be signed in with an administrator account to manage funding resources."
        action={<Button asChild><Link href="/login">Sign in</Link></Button>}
      />
    );
  }

  return (
    <EmptyState
      icon={ShieldAlert}
      title="Administrators only"
      description="Your account doesn’t have permission to manage funding resources."
    />
  );
}
