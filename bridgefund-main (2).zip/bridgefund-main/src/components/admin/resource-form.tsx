"use client";

import { useState } from "react";

import { Field, fieldProps } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { COUNTRY_OPTIONS } from "@/config/countries";
import {
  DEADLINE_TYPE_LABELS,
  EDUCATION_LEVEL_LABELS,
  ENROLLMENT_LABELS,
  EXPENSE_CATEGORY_LABELS,
  FIELD_OF_STUDY_LABELS,
  OPPORTUNITY_TYPE_LABELS,
  RESOURCE_KIND_LABELS,
} from "@/config/option-labels";
import { validateResource, type ResourceErrors } from "@/lib/resources/validation";
import {
  BARRIER_CATEGORIES,
  CURRENCY_CODES,
  EDUCATION_LEVELS,
  ENROLLMENT_STATUSES,
  FIELDS_OF_STUDY,
  RESOURCE_KINDS,
  type Criterion,
  type CurrencyCode,
  type DateOnlyString,
  type DeadlineType,
  type OpportunityType,
  type ResourceValue,
  type SupportResource,
  type TriState,
} from "@/types";

interface Option<T extends string> {
  value: T;
  label: string;
}

const COUNTRY_CHOICES: Option<string>[] = COUNTRY_OPTIONS.filter((c) => c.code !== "OTHER").map((c) => ({
  value: c.code,
  label: c.name,
}));
const toOptions = <T extends string>(list: readonly T[], labels: Record<T, string>): Option<T>[] =>
  list.map((value) => ({ value, label: labels[value] }));

const EDUCATION_OPTIONS = toOptions(EDUCATION_LEVELS, EDUCATION_LEVEL_LABELS);
const OPPORTUNITY_OPTIONS = toOptions(["program", "scholarship", "course", "exam"] as OpportunityType[], OPPORTUNITY_TYPE_LABELS);
const FIELD_OPTIONS = toOptions(FIELDS_OF_STUDY, FIELD_OF_STUDY_LABELS);
const ENROLLMENT_OPTIONS = toOptions(ENROLLMENT_STATUSES, ENROLLMENT_LABELS);

/** Unknown / Any / Only-these editor for one eligibility rule. */
function CriterionEditor<T extends string>({
  id,
  label,
  value,
  options,
  onChange,
}: {
  id: string;
  label: string;
  value: Criterion<T>;
  options: Option<T>[];
  onChange: (next: Criterion<T>) => void;
}) {
  const selected = value.mode === "only" ? value.values : [];
  return (
    <div className="space-y-2 rounded-lg border border-border p-3">
      <Field id={id} label={label}>
        <Select
          id={id}
          value={value.mode}
          onChange={(e) => {
            const mode = e.target.value;
            onChange(mode === "only" ? { mode: "only", values: selected } : { mode: mode === "any" ? "any" : "unknown" });
          }}
        >
          <option value="unknown">Unknown (not recorded)</option>
          <option value="any">Any: confirmed no restriction</option>
          <option value="only">Only these…</option>
        </Select>
      </Field>
      {value.mode === "only" ? (
        <fieldset className="max-h-44 overflow-y-auto rounded-md bg-muted/50 p-2">
          <legend className="sr-only">{label}: allowed values</legend>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {options.map((o) => (
              <div key={o.value} className="flex items-center gap-2">
                <Checkbox
                  id={`${id}-${o.value}`}
                  checked={selected.includes(o.value)}
                  onChange={(e) =>
                    onChange({
                      mode: "only",
                      values: e.target.checked ? [...selected, o.value] : selected.filter((v) => v !== o.value),
                    })
                  }
                />
                <Label htmlFor={`${id}-${o.value}`} className="font-normal">{o.label}</Label>
              </div>
            ))}
          </div>
        </fieldset>
      ) : (
        <p className="text-xs text-muted-foreground">
          {value.mode === "any"
            ? "Use only when the provider confirms there is no restriction."
            : "Students will see this as unconfirmed, never as eligible."}
        </p>
      )}
    </div>
  );
}

interface ResourceFormProps {
  initial: SupportResource;
  isNew: boolean;
  today: DateOnlyString;
  onSave: (resource: SupportResource) => void;
  onCancel: () => void;
}

export function ResourceForm({ initial, isNew, today, onSave, onCancel }: ResourceFormProps) {
  const [r, setR] = useState<SupportResource>(initial);
  const [errors, setErrors] = useState<ResourceErrors>({});
  const [requirementsText, setRequirementsText] = useState(initial.eligibility.additionalRequirements.join("\n"));

  const patch = (p: Partial<SupportResource>) => setR((prev) => ({ ...prev, ...p }));
  const patchElig = (p: Partial<SupportResource["eligibility"]>) =>
    setR((prev) => ({ ...prev, eligibility: { ...prev.eligibility, ...p } }));

  const setValueKind = (kind: ResourceValue["kind"]) => {
    const currency: CurrencyCode = "currency" in r.value ? r.value.currency : "USD";
    patch({
      value:
        kind === "full" ? { kind: "full" }
        : kind === "percent" ? { kind: "percent", percent: 0 }
        : kind === "range" ? { kind: "range", min: 0, max: 0, currency }
        : { kind: "fixed", amount: 0, currency },
    });
  };
  const num = (s: string) => (s === "" ? 0 : Number(s));

  const submit = (ev: React.SyntheticEvent) => {
    ev.preventDefault();
    const next: SupportResource = {
      ...r,
      name: r.name.trim(),
      provider: r.provider.trim(),
      applicationUrl: r.applicationUrl?.trim() || undefined,
      deadline: r.deadlineType === "fixed" ? r.deadline : undefined,
      eligibility: {
        ...r.eligibility,
        additionalRequirements: requirementsText.split("\n").map((l) => l.trim()).filter(Boolean),
      },
    };
    const found = validateResource(next, today);
    // A passed deadline is a warning (the listing will show as expired), not a blocker.
    const blocking = Object.fromEntries(
      Object.entries(found).filter(([k, v]) => !(k === "deadline" && /has passed/.test(v ?? ""))),
    );
    setErrors(found);
    if (Object.keys(blocking).length > 0) return;
    onSave(next);
  };

  const value = r.value;
  const p = (id: string, hint = false) => fieldProps(id, { hint, error: errors[id] });

  return (
    <form onSubmit={submit} noValidate className="space-y-6">
      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>{isNew ? "New funding resource" : "Edit funding resource"}</CardTitle>
          <CardDescription>
            {isNew
              ? "New listings start Unverified. Verify them after checking the provider’s own source."
              : initial.verification === "verified"
                ? "Changing eligibility, amount, deadline, links, or coverage moves a Verified listing back to Requires re-verification."
                : "Verification status is changed with the Verify and Expire actions, not here."}
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <Field id="name" label="Resource name" required error={errors.name}>
            <Input {...p("name")} value={r.name} onChange={(e) => patch({ name: e.target.value })} />
          </Field>
          <Field id="provider" label="Provider" required error={errors.provider}>
            <Input {...p("provider")} value={r.provider} onChange={(e) => patch({ provider: e.target.value })} />
          </Field>
          <Field id="description" label="Description" required error={errors.description} className="sm:col-span-2">
            <Textarea {...p("description")} value={r.description} onChange={(e) => patch({ description: e.target.value })} />
          </Field>
          <Field id="country" label="Country or region" required hint="Where the program is based." error={errors.country}>
            <Select {...p("country", true)} value={r.country} onChange={(e) => patch({ country: e.target.value })}>
              <option value="GLOBAL">Global</option>
              <option value="EU">Europe (regional)</option>
              {COUNTRY_CHOICES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </Select>
          </Field>
          <Field id="kind" label="Support type" required>
            <Select id="kind" value={r.kind} onChange={(e) => patch({ kind: e.target.value as SupportResource["kind"] })}>
              {RESOURCE_KINDS.map((k) => <option key={k} value={k}>{RESOURCE_KIND_LABELS[k]}</option>)}
            </Select>
          </Field>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Assistance and expenses</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-4">
            <Field id="value-kind" label="Amount type" className="sm:col-span-1">
              <Select id="value-kind" value={value.kind} onChange={(e) => setValueKind(e.target.value as ResourceValue["kind"])}>
                <option value="fixed">Up to a fixed amount</option>
                <option value="range">Range</option>
                <option value="percent">Percent of cost</option>
                <option value="full">Covers the full cost</option>
              </Select>
            </Field>
            {value.kind === "fixed" ? (
              <Field id="value" label="Amount" required error={errors.value}>
                <Input {...p("value")} type="number" min="0" step="any" value={value.amount || ""} onChange={(e) => patch({ value: { ...value, amount: num(e.target.value) } })} />
              </Field>
            ) : null}
            {value.kind === "range" ? (
              <>
                <Field id="value" label="Minimum" required error={errors.value}>
                  <Input {...p("value")} type="number" min="0" step="any" value={value.min || ""} onChange={(e) => patch({ value: { ...value, min: num(e.target.value) } })} />
                </Field>
                <Field id="value-max" label="Maximum" required hint="Plans use the minimum.">
                  <Input id="value-max" type="number" min="0" step="any" value={value.max || ""} onChange={(e) => patch({ value: { ...value, max: num(e.target.value) } })} />
                </Field>
              </>
            ) : null}
            {value.kind === "percent" ? (
              <Field id="value" label="Percent" required error={errors.value}>
                <Input {...p("value")} type="number" min="1" max="100" value={value.percent || ""} onChange={(e) => patch({ value: { ...value, percent: num(e.target.value) } })} />
              </Field>
            ) : null}
            {value.kind === "fixed" || value.kind === "range" ? (
              <Field id="value-currency" label="Currency">
                <Select id="value-currency" value={value.currency} onChange={(e) => patch({ value: { ...value, currency: e.target.value as CurrencyCode } })}>
                  {CURRENCY_CODES.map((c) => <option key={c} value={c}>{c}</option>)}
                </Select>
              </Field>
            ) : null}
          </div>

          <fieldset aria-describedby={errors.categories ? "categories-error" : undefined}>
            <legend className="text-sm font-medium text-foreground">
              Eligible expense categories <span className="text-destructive" aria-hidden="true">*</span>
            </legend>
            <div className="mt-2 grid gap-2 sm:grid-cols-4">
              {BARRIER_CATEGORIES.map((c) => (
                <div key={c} className="flex items-center gap-2">
                  <Checkbox
                    id={`cat-${c}`}
                    checked={r.categories.includes(c)}
                    onChange={(e) =>
                      patch({ categories: e.target.checked ? [...r.categories, c] : r.categories.filter((x) => x !== c) })
                    }
                  />
                  <Label htmlFor={`cat-${c}`} className="font-normal">{EXPENSE_CATEGORY_LABELS[c]}</Label>
                </div>
              ))}
            </div>
            {errors.categories ? <p id="categories-error" className="mt-1 text-xs font-medium text-destructive-foreground">{errors.categories}</p> : null}
          </fieldset>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Eligibility requirements</CardTitle>
          <CardDescription>
            Record each rule as Unknown, Any, or Only these. Unknown is never treated as eligible when students are matched.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field id="summary" label="Plain-language summary" required error={errors.summary}>
            <Textarea {...p("summary")} value={r.eligibility.summary} onChange={(e) => patchElig({ summary: e.target.value })} />
          </Field>
          {errors.eligibility ? <p className="text-xs font-medium text-destructive-foreground">{errors.eligibility}</p> : null}
          <div className="grid gap-4 lg:grid-cols-2">
            <CriterionEditor id="elig-residence" label="Student’s country of residence" value={r.eligibility.residence} options={COUNTRY_CHOICES} onChange={(c) => patchElig({ residence: c })} />
            <CriterionEditor id="elig-study" label="Country of the opportunity" value={r.eligibility.studyCountries} options={COUNTRY_CHOICES} onChange={(c) => patchElig({ studyCountries: c })} />
            <CriterionEditor id="elig-education" label="Education levels" value={r.eligibility.educationLevels} options={EDUCATION_OPTIONS} onChange={(c) => patchElig({ educationLevels: c })} />
            <CriterionEditor id="elig-type" label="Opportunity types" value={r.eligibility.opportunityTypes} options={OPPORTUNITY_OPTIONS} onChange={(c) => patchElig({ opportunityTypes: c })} />
            <CriterionEditor id="elig-field" label="Fields of study" value={r.eligibility.fieldsOfStudy} options={FIELD_OPTIONS} onChange={(c) => patchElig({ fieldsOfStudy: c })} />
            <CriterionEditor id="elig-enrollment" label="Enrollment status" value={r.eligibility.enrollment} options={ENROLLMENT_OPTIONS} onChange={(c) => patchElig({ enrollment: c })} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field id="need" label="Tests financial need?">
              <Select id="need" value={r.eligibility.needBased} onChange={(e) => patchElig({ needBased: e.target.value as TriState })}>
                <option value="unknown">Unknown (not recorded)</option>
                <option value="yes">Yes, need-based</option>
                <option value="no">No need test</option>
              </Select>
            </Field>
            <Field id="extra" label="Other requirements" hint="One per line. BridgeFund can’t check these, so students are told to confirm them.">
              <Textarea id="extra" aria-describedby="extra-hint" value={requirementsText} onChange={(e) => setRequirementsText(e.target.value)} />
            </Field>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Deadline and how to apply</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <Field id="deadline-type" label="Deadline type">
            <Select id="deadline-type" value={r.deadlineType} onChange={(e) => patch({ deadlineType: e.target.value as DeadlineType })}>
              {(["fixed", "rolling", "unknown"] as DeadlineType[]).map((d) => <option key={d} value={d}>{DEADLINE_TYPE_LABELS[d]}</option>)}
            </Select>
          </Field>
          {r.deadlineType === "fixed" ? (
            <Field id="deadline" label="Application deadline" required error={errors.deadline}>
              <Input {...p("deadline")} type="date" value={r.deadline ?? ""} onChange={(e) => patch({ deadline: e.target.value || undefined })} />
            </Field>
          ) : null}
          <Field id="officialUrl" label="Official website" required hint="Full https:// link to the provider." error={errors.officialUrl}>
            <Input {...p("officialUrl", true)} type="url" inputMode="url" placeholder="https://" value={r.officialUrl} onChange={(e) => patch({ officialUrl: e.target.value })} />
          </Field>
          <Field id="sourceName" label="Website label" required error={errors.sourceName}>
            <Input {...p("sourceName")} value={r.sourceName} onChange={(e) => patch({ sourceName: e.target.value })} />
          </Field>
          <Field id="applicationUrl" label="Application link" hint="Optional. Defaults to the official website." error={errors.applicationUrl} className="sm:col-span-2">
            <Input {...p("applicationUrl", true)} type="url" inputMode="url" placeholder="https://" value={r.applicationUrl ?? ""} onChange={(e) => patch({ applicationUrl: e.target.value })} />
          </Field>
          <Field id="applicationInstructions" label="Application instructions" required error={errors.applicationInstructions} className="sm:col-span-2">
            <Textarea {...p("applicationInstructions")} value={r.applicationInstructions} onChange={(e) => patch({ applicationInstructions: e.target.value })} />
          </Field>
          <div className="flex items-center gap-2 sm:col-span-2">
            <Checkbox id="isDemo" checked={r.isDemo} onChange={(e) => patch({ isDemo: e.target.checked })} />
            <Label htmlFor="isDemo" className="font-normal">This is fictional sample data (shown to students as DEMO DATA)</Label>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit">{isNew ? "Create listing" : "Save changes"}</Button>
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        {Object.keys(errors).length > 0 ? (
          <p role="alert" className="text-sm font-medium text-destructive-foreground">Fix the highlighted fields to continue.</p>
        ) : null}
      </div>
    </form>
  );
}
