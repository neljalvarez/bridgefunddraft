"use client";

import { Archive, Ban, Pencil, Plus, RotateCcw, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";

import { PortalSkeleton } from "@/components/shared/portal-skeleton";
import { StatCard } from "@/components/shared/stat-card";
import { DemoBadge, VerificationBadge } from "@/components/shared/verification-badge";
import { Field } from "@/components/shared/form-field";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RESOURCE_KIND_LABELS } from "@/config/option-labels";
import { RESOURCE_VERIFICATION_META } from "@/config/status";
import { useResourceCatalog } from "@/hooks/use-resource-catalog";
import { formatDay } from "@/lib/format";
import { describeValue } from "@/lib/gap/matching";
import { matchesQuery } from "@/lib/resources/discovery";
import {
  applyEdit,
  archiveResource,
  expireResource,
  restoreResource,
  verifyResource,
  MIN_EVIDENCE_LENGTH,
} from "@/lib/resources/lifecycle";
import { createBlankResource } from "@/lib/resources/validation";
import { effectiveVerification } from "@/lib/resources/verification";
import { RESOURCE_VERIFICATION_STATUSES, type SupportResource } from "@/types";

import { ResourceForm } from "./resource-form";

type Mode =
  | { type: "list" }
  | { type: "form"; id: string | null }
  | { type: "verify"; id: string }
  | { type: "expire"; id: string };

export function ResourcesAdminView() {
  const catalog = useResourceCatalog();
  const [mode, setMode] = useState<Mode>({ type: "list" });
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"all" | (typeof RESOURCE_VERIFICATION_STATUSES)[number]>("all");
  const [showArchived, setShowArchived] = useState(false);
  const [verifyDate, setVerifyDate] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  const resources = catalog?.resources;
  const today = catalog?.today;

  const counts = useMemo(() => {
    const c = { verified: 0, requires_reverification: 0, unverified: 0, expired: 0, archived: 0 };
    if (!resources || !today) return c;
    for (const r of resources) {
      if (r.archivedAt) c.archived++;
      else c[effectiveVerification(r, today)]++;
    }
    return c;
  }, [resources, today]);

  const rows = useMemo(() => {
    if (!resources || !today) return [];
    return resources.filter((r) => {
      if (!showArchived && r.archivedAt) return false;
      if (status !== "all" && effectiveVerification(r, today) !== status) return false;
      return matchesQuery(r, query);
    });
  }, [resources, today, status, showArchived, query]);

  if (!catalog || !today || !resources) return <PortalSkeleton />;
  const { actions, stored } = catalog;
  const now = () => new Date().toISOString();
  const back = () => {
    setMode({ type: "list" });
    setNote("");
    setError(null);
  };
  const find = (id: string | null) => resources.find((r) => r.id === id) ?? null;

  /* ------------------------------- Edit / create ------------------------------ */
  if (mode.type === "form") {
    const existing = find(mode.id);
    return (
      <ResourceForm
        key={mode.id ?? "new"}
        initial={existing ?? createBlankResource()}
        isNew={!existing}
        today={today}
        onCancel={back}
        onSave={(draft) => {
          if (existing) actions.save(applyEdit(existing, draft, now()));
          else actions.create(draft, now());
          back();
        }}
      />
    );
  }

  /* --------------------------------- Verify ---------------------------------- */
  if (mode.type === "verify") {
    const r = find(mode.id);
    if (!r) return null;
    const date = verifyDate || today;
    return (
      <Card className="max-w-2xl shadow-none">
        <CardHeader>
          <CardTitle>Verify “{r.name}”</CardTitle>
          <CardDescription>
            Only mark a listing Verified after checking it against the provider’s own source. Students see the date and your evidence note.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field id="verify-date" label="Date you checked it" required>
            <Input id="verify-date" type="date" max={today} value={date} onChange={(e) => setVerifyDate(e.target.value)} />
          </Field>
          <Field
            id="verify-note"
            label="Evidence"
            required
            hint={`What you checked and where (at least ${MIN_EVIDENCE_LENGTH} characters). For example: “Confirmed amount, deadline and eligibility on the provider’s official page.”`}
            error={error ?? undefined}
          >
            <Textarea id="verify-note" aria-describedby="verify-note-hint" value={note} onChange={(e) => setNote(e.target.value)} />
          </Field>
          <div className="flex gap-3">
            <Button
              onClick={() => {
                const result = verifyResource(r, { date, note }, today, now());
                if (!result.ok) return setError(result.error);
                actions.save(result.resource);
                setVerifyDate("");
                back();
              }}
            >
              <ShieldCheck /> Mark as verified
            </Button>
            <Button variant="outline" onClick={back}>Cancel</Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  /* --------------------------------- Expire ---------------------------------- */
  if (mode.type === "expire") {
    const r = find(mode.id);
    if (!r) return null;
    return (
      <Card className="max-w-2xl shadow-none">
        <CardHeader>
          <CardTitle>Expire “{r.name}”</CardTitle>
          <CardDescription>
            Expired listings disappear from student search and are never matched. Students who saved one will see that it has expired.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field id="expire-note" label="Reason" hint="Optional. For example: the provider closed the fund.">
            <Textarea id="expire-note" aria-describedby="expire-note-hint" value={note} onChange={(e) => setNote(e.target.value)} />
          </Field>
          <div className="flex gap-3">
            <Button
              variant="navy"
              onClick={() => {
                actions.save(expireResource(r, note, now()));
                back();
              }}
            >
              <Ban /> Mark as expired
            </Button>
            <Button variant="outline" onClick={back}>Cancel</Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  /* ---------------------------------- List ----------------------------------- */
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Verified" value={counts.verified} icon={ShieldCheck} />
        <StatCard label="Requires re-verification" value={counts.requires_reverification} icon={RotateCcw} />
        <StatCard label="Unverified" value={counts.unverified} icon={Pencil} />
        <StatCard label="Expired" value={counts.expired} icon={Ban} />
        <StatCard label="Archived" value={counts.archived} icon={Archive} />
      </div>

      <div className="flex flex-wrap items-end gap-4 rounded-xl border border-border bg-card p-5">
        <Field id="admin-q" label="Search" className="w-full sm:w-64">
          <Input id="admin-q" type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Name, provider, country…" />
        </Field>
        <Field id="admin-status" label="Status" className="w-full sm:w-56">
          <Select id="admin-status" value={status} onChange={(e) => setStatus(e.target.value as typeof status)}>
            <option value="all">All statuses</option>
            {RESOURCE_VERIFICATION_STATUSES.map((s) => (
              <option key={s} value={s}>{RESOURCE_VERIFICATION_META[s].label}</option>
            ))}
          </Select>
        </Field>
        <div className="flex items-center gap-2 pb-2.5">
          <Checkbox id="admin-archived" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} />
          <Label htmlFor="admin-archived" className="font-normal">Show archived</Label>
        </div>
        <Button className="ml-auto" onClick={() => setMode({ type: "form", id: null })}>
          <Plus /> New resource
        </Button>
      </div>

      <p role="status" aria-live="polite" className="text-sm text-muted-foreground">
        {rows.length} listing{rows.length === 1 ? "" : "s"}. Statuses shown are what students see: a Verified listing whose
        evidence is over 180 days old, or whose deadline has passed, is shown as stale or expired automatically.
      </p>

      <ul className="space-y-3">
        {rows.map((r: SupportResource) => {
          const eff = effectiveVerification(r, today);
          return (
            <li key={r.id}>
              <Card className="p-4 shadow-none">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="min-w-0 flex-1 basis-72">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-semibold text-navy">{r.name}</h3>
                      <VerificationBadge resource={r} today={today} />
                      {r.isDemo ? <DemoBadge /> : null}
                      {r.archivedAt ? <Badge tone="neutral">Archived</Badge> : null}
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {r.provider} · {RESOURCE_KIND_LABELS[r.kind]} · {describeValue(r)}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Deadline:{" "}
                      {r.deadlineType === "fixed" && r.deadline ? formatDay(r.deadline) : r.deadlineType === "rolling" ? "Rolling" : "Not recorded"}
                      {" · "}
                      Last verified: {r.lastVerifiedDate ? formatDay(r.lastVerifiedDate) : "never"}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" variant="outline" onClick={() => setMode({ type: "form", id: r.id })}>
                      <Pencil /> Edit
                    </Button>
                    {!r.archivedAt && eff !== "verified" ? (
                      <Button size="sm" variant="outline" onClick={() => { setError(null); setNote(""); setMode({ type: "verify", id: r.id }); }}>
                        <ShieldCheck /> Verify
                      </Button>
                    ) : null}
                    {!r.archivedAt && r.verification !== "expired" ? (
                      <Button size="sm" variant="outline" onClick={() => { setNote(""); setMode({ type: "expire", id: r.id }); }}>
                        <Ban /> Expire
                      </Button>
                    ) : null}
                    {r.archivedAt ? (
                      <Button size="sm" variant="outline" onClick={() => actions.save(restoreResource(r, now()))}>
                        <RotateCcw /> Restore
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => actions.save(archiveResource(r, now()))}>
                        <Archive /> Archive
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            </li>
          );
        })}
      </ul>

      <Card className="shadow-none">
        <CardHeader>
          <CardTitle>Demo data</CardTitle>
          <CardDescription>
            The fictional DEMO DATA listings can be hidden once you have real, verified ones. Resetting discards every edit and new listing.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Button variant="outline" onClick={() => actions.setHideDemo(!stored.hideDemo)}>
            {stored.hideDemo ? "Show demo listings" : "Hide demo listings"}
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              if (window.confirm("Discard all edits and created listings and restore the demo catalog?")) actions.reset();
            }}
          >
            Reset catalog
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
