import { getCountryName, OTHER_COUNTRY } from "@/config/countries";
import {
  EDUCATION_LEVEL_LABELS,
  ENROLLMENT_LABELS,
  EXPENSE_CATEGORY_LABELS,
  FIELD_OF_STUDY_LABELS,
  OPPORTUNITY_TYPE_LABELS,
} from "@/config/option-labels";
import { daysBetween } from "@/lib/dates";
import { formatDay } from "@/lib/format";
import {
  effectiveVerification,
  VERIFICATION_RANK,
} from "@/lib/resources/verification";
import { resourceValueFor } from "@/lib/resources/value";
import type {
  Criterion,
  DateOnlyString,
  Expense,
  OpportunityType,
  StudentProfile,
  SupportResource,
} from "@/types";

/* -------------------------------------------------------------------------
 * Transparent, rule-based funding matcher.
 *
 * How a score is made (nothing here is learned or hidden):
 *
 *  1. Six factors each have a fixed weight; the weights add up to 100.
 *  2. Each factor is a short list of CHECKS. A check is pass, fail, or unknown.
 *     A factor earns its weight times the share of its checks that passed.
 *  3. HARD RULES OVERRIDE THE SCORE. If any check fails, the listing is
 *     "excluded" and scores 0, however well the rest matched.
 *  4. UNKNOWN IS NEVER ELIGIBLE. An unknown check earns no points, is listed
 *     under "missing information", and caps the score so an unconfirmed match
 *     can never look like a strong one.
 *  5. An unverified or stale listing is capped too: BridgeFund won't rank a
 *     listing nobody has confirmed as a top match.
 * ---------------------------------------------------------------------- */

export const MATCH_WEIGHTS = {
  location: 25,
  expense: 25,
  education: 15,
  opportunityType: 15,
  deadline: 10,
  requirements: 10,
} as const;

export type FactorKey = keyof typeof MATCH_WEIGHTS;

export const FACTOR_LABELS: Record<FactorKey, string> = {
  location: "Location",
  expense: "Expense compatibility",
  education: "Education level",
  opportunityType: "Opportunity type",
  deadline: "Deadline",
  requirements: "Other requirements",
};

/** A score above this is impossible while any eligibility check is unknown. */
export const NEEDS_INFO_CAP = 59;
/** A score above this is impossible for an unverified or stale listing. */
export const UNVERIFIED_CAP = 79;
export const STRONG_FROM = 80;
export const GOOD_FROM = 60;

export type CheckState = "pass" | "fail" | "unknown";

export interface Check {
  label: string;
  state: CheckState;
  /** Plain-language result, e.g. "Open to residents of Portugal". */
  detail: string;
  /** Share of the factor's weight this check earns when it passes (0 to 1). */
  credit: number;
}

export interface FactorResult {
  key: FactorKey;
  label: string;
  weight: number;
  /** Worst state among the checks: fail, else unknown, else pass. */
  state: CheckState;
  points: number;
  checks: Check[];
}

export interface MissingInfo {
  /** "you": the student can supply it. "listing": the listing doesn't say. */
  who: "you" | "listing";
  field: string;
  message: string;
}

export type EligibilityStatus = "criteria_met" | "needs_info" | "excluded";
export type MatchBand = "strong" | "good" | "possible" | "excluded";

export interface ScoreCap {
  limit: number;
  reason: string;
}

export interface MatchEvaluation {
  resourceId: string;
  expenseId: string;
  status: EligibilityStatus;
  /** 0 to 100. Always 0 when excluded. */
  score: number;
  /** The score before caps were applied (0 when excluded). */
  uncappedScore: number;
  caps: ScoreCap[];
  band: MatchBand;
  factors: FactorResult[];
  /** Why it was recommended: every check that passed. */
  reasons: string[];
  /** Why it is excluded: every check that failed. Empty unless excluded. */
  exclusions: string[];
  missing: MissingInfo[];
  /** Potential value for this expense, in the expense's currency (0 if excluded). */
  value: number;
  /** Days until the listing's deadline; null for rolling or unknown. */
  daysLeft: number | null;
}

export interface EvaluateArgs {
  resource: SupportResource;
  expense: Pick<Expense, "id" | "amount" | "currency" | "category" | "name">;
  opportunity: { type: OpportunityType; country?: string };
  profile: StudentProfile;
  today: DateOnlyString;
}

/* --------------------------------- Helpers -------------------------------- */

const lower = (s: string) => s.charAt(0).toLowerCase() + s.slice(1);

interface CriterionArgs<T extends string> {
  label: string;
  criterion: Criterion<T>;
  /** The student's/opportunity's value, or null when not known. */
  actual: T | null;
  actualLabel: (v: T) => string;
  valueLabel: (v: T) => string;
  /** Short name used in missing-info messages, e.g. "your education level". */
  actualField: string;
  anyDetail: string;
  passDetail: (actual: string) => string;
  failDetail: (actual: string, allowed: string) => string;
}

function checkCriterion<T extends string>(
  a: CriterionArgs<T>,
): { check: Check; missing?: MissingInfo } {
  const { criterion } = a;

  if (criterion.mode === "any") {
    return { check: { label: a.label, state: "pass", detail: a.anyDetail, credit: 1 } };
  }

  // An "only" list with no values is a data-entry mistake: treat as unrecorded.
  if (criterion.mode === "unknown" || criterion.values.length === 0) {
    return {
      check: {
        label: a.label,
        state: "unknown",
        detail: `The listing doesn’t say who qualifies by ${a.label.toLowerCase()}.`,
        credit: 1,
      },
      missing: {
        who: "listing",
        field: a.label,
        message: `The listing doesn’t record its ${a.label.toLowerCase()} rule. Check the provider’s site before relying on it.`,
      },
    };
  }

  if (a.actual === null) {
    return {
      check: {
        label: a.label,
        state: "unknown",
        detail: `Limited to ${criterion.values.map(a.valueLabel).join(", ")}, and ${a.actualField} isn’t set.`,
        credit: 1,
      },
      missing: {
        who: "you",
        field: a.label,
        message: `Add ${a.actualField} so we can check this listing’s ${a.label.toLowerCase()} rule.`,
      },
    };
  }

  const allowed = criterion.values.map(a.valueLabel).join(", ");
  return criterion.values.includes(a.actual)
    ? { check: { label: a.label, state: "pass", detail: a.passDetail(a.actualLabel(a.actual)), credit: 1 } }
    : { check: { label: a.label, state: "fail", detail: a.failDetail(a.actualLabel(a.actual), allowed), credit: 1 } };
}

/** "" and "OTHER" are both "we can't tell which country". */
const knownCountry = (code: string | undefined): string | null =>
  code && code !== OTHER_COUNTRY ? code : null;

function buildFactor(
  key: FactorKey,
  checks: Check[],
): FactorResult {
  const weight = MATCH_WEIGHTS[key];
  const total = checks.reduce((n, c) => n + c.credit, 0) || 1;
  const earned = checks
    .filter((c) => c.state === "pass")
    .reduce((n, c) => n + c.credit, 0);
  const state: CheckState = checks.some((c) => c.state === "fail")
    ? "fail"
    : checks.some((c) => c.state === "unknown")
      ? "unknown"
      : "pass";
  return {
    key,
    label: FACTOR_LABELS[key],
    weight,
    state,
    points: Math.round(((weight * earned) / total) * 10) / 10,
    checks,
  };
}

/* ---------------------------------- Factors ------------------------------- */

function locationFactor(
  { resource, opportunity, profile }: EvaluateArgs,
  missing: MissingInfo[],
): FactorResult {
  const e = resource.eligibility;
  const residence = checkCriterion<string>({
    label: "Country of residence",
    criterion: e.residence,
    actual: knownCountry(profile.residenceCountry),
    actualLabel: getCountryName,
    valueLabel: getCountryName,
    actualField: "your country of residence",
    anyDetail: "Open to residents of any country.",
    passDetail: (c) => `Open to residents of ${c}.`,
    failDetail: (c, allowed) => `Limited to residents of ${allowed}; you live in ${c}.`,
  });
  const study = checkCriterion<string>({
    label: "Study location",
    criterion: e.studyCountries,
    actual: knownCountry(opportunity.country),
    actualLabel: getCountryName,
    valueLabel: getCountryName,
    actualField: "the opportunity’s country",
    anyDetail: "Open to opportunities in any country.",
    passDetail: (c) => `Supports opportunities in ${c}.`,
    failDetail: (c, allowed) => `Limited to opportunities in ${allowed}; this one is in ${c}.`,
  });
  for (const r of [residence, study]) if (r.missing) missing.push(r.missing);
  return buildFactor("location", [residence.check, study.check]);
}

function expenseFactor(
  { resource, expense }: EvaluateArgs,
  missing: MissingInfo[],
): FactorResult {
  const cat = EXPENSE_CATEGORY_LABELS[expense.category];
  let check: Check;
  if (resource.categories.length === 0) {
    check = {
      label: "Expense category",
      state: "unknown",
      detail: "The listing doesn’t say which costs it covers.",
      credit: 1,
    };
    missing.push({
      who: "listing",
      field: "Expense category",
      message: "The listing doesn’t record which kinds of cost it covers.",
    });
  } else if (resource.categories.includes(expense.category)) {
    check = {
      label: "Expense category",
      state: "pass",
      detail: `Covers ${lower(cat)} costs.`,
      credit: 1,
    };
  } else {
    check = {
      label: "Expense category",
      state: "fail",
      detail: `Does not cover ${lower(cat)} costs (covers ${resource.categories
        .map((c) => lower(EXPENSE_CATEGORY_LABELS[c]))
        .join(", ")}).`,
      credit: 1,
    };
  }
  return buildFactor("expense", [check]);
}

function educationFactor(
  { resource, profile }: EvaluateArgs,
  missing: MissingInfo[],
): FactorResult {
  const r = checkCriterion({
    label: "Education level",
    criterion: resource.eligibility.educationLevels,
    actual: profile.educationLevel || null,
    actualLabel: (v) => EDUCATION_LEVEL_LABELS[v],
    valueLabel: (v) => EDUCATION_LEVEL_LABELS[v],
    actualField: "your education level",
    anyDetail: "Open to every education level.",
    passDetail: (a) => `Open to ${lower(a)} students.`,
    failDetail: (a, allowed) => `Limited to ${allowed}; you chose ${a}.`,
  });
  if (r.missing) missing.push(r.missing);
  return buildFactor("education", [r.check]);
}

function opportunityTypeFactor(
  { resource, opportunity }: EvaluateArgs,
  missing: MissingInfo[],
): FactorResult {
  const r = checkCriterion({
    label: "Opportunity type",
    criterion: resource.eligibility.opportunityTypes,
    actual: opportunity.type,
    actualLabel: (v) => OPPORTUNITY_TYPE_LABELS[v],
    valueLabel: (v) => OPPORTUNITY_TYPE_LABELS[v],
    actualField: "the opportunity type",
    anyDetail: "Open to every kind of opportunity.",
    passDetail: (a) => `For ${lower(a)} opportunities.`,
    failDetail: (a, allowed) => `Limited to ${lower(allowed)} opportunities; this is a ${lower(a)}.`,
  });
  if (r.missing) missing.push(r.missing);
  return buildFactor("opportunityType", [r.check]);
}

/** Share of the deadline credit by how much time is left. */
function deadlineCredit(daysLeft: number): number {
  if (daysLeft >= 14) return 1;
  if (daysLeft >= 7) return 0.7;
  return 0.4;
}

function deadlineFactor(
  { resource, today }: EvaluateArgs,
  missing: MissingInfo[],
): { factor: FactorResult; daysLeft: number | null } {
  let check: Check;
  let daysLeft: number | null = null;

  if (resource.deadlineType === "rolling") {
    check = {
      label: "Deadline",
      state: "pass",
      detail: "Rolling applications, no fixed deadline. Confirm the provider is still accepting them.",
      credit: 1,
    };
  } else if (resource.deadlineType === "fixed" && resource.deadline) {
    daysLeft = daysBetween(today, resource.deadline);
    if (daysLeft < 0) {
      check = {
        label: "Deadline",
        state: "fail",
        detail: `Closed on ${formatDay(resource.deadline)}.`,
        credit: 1,
      };
    } else {
      const soon = daysLeft < 7 ? " Closing soon." : "";
      check = {
        label: "Deadline",
        state: "pass",
        detail: `Open until ${formatDay(resource.deadline)}.${soon}`,
        credit: deadlineCredit(daysLeft),
      };
    }
  } else {
    check = {
      label: "Deadline",
      state: "unknown",
      detail: "The listing has no recorded deadline, so we can’t tell if it is open.",
      credit: 1,
    };
    missing.push({
      who: "listing",
      field: "Deadline",
      message: "No deadline is recorded. Check with the provider whether applications are open.",
    });
  }

  // Partial credit: a passing check with credit < 1 earns that share only.
  const weight = MATCH_WEIGHTS.deadline;
  const earned = check.state === "pass" ? check.credit : 0;
  return {
    factor: {
      key: "deadline",
      label: FACTOR_LABELS.deadline,
      weight,
      state: check.state,
      points: Math.round(weight * earned * 10) / 10,
      checks: [check],
    },
    daysLeft,
  };
}

function requirementsFactor(
  { resource, profile }: EvaluateArgs,
  missing: MissingInfo[],
): FactorResult {
  const e = resource.eligibility;
  const checks: Check[] = [];

  // Financial need.
  if (e.needBased === "no") {
    checks.push({ label: "Financial need", state: "pass", detail: "No financial-need test.", credit: 1 });
  } else if (e.needBased === "yes") {
    if (profile.openToNeedBased) {
      checks.push({
        label: "Financial need",
        state: "pass",
        detail: "Need-based. You chose to be considered; the provider verifies need itself.",
        credit: 1,
      });
    } else {
      checks.push({
        label: "Financial need",
        state: "fail",
        detail: "Need-based, and you haven’t chosen to be considered for need-based support (change this in Settings).",
        credit: 1,
      });
    }
  } else {
    checks.push({
      label: "Financial need",
      state: "unknown",
      detail: "The listing doesn’t say whether financial need is tested.",
      credit: 1,
    });
    missing.push({
      who: "listing",
      field: "Financial need",
      message: "The listing doesn’t say whether it is need-based.",
    });
  }

  // Enrollment.
  const enr = checkCriterion({
    label: "Enrollment status",
    criterion: e.enrollment,
    actual: profile.enrollment || null,
    actualLabel: (v) => ENROLLMENT_LABELS[v],
    valueLabel: (v) => ENROLLMENT_LABELS[v],
    actualField: "your enrollment status",
    anyDetail: "Open regardless of enrollment status.",
    passDetail: (a) => `Open to students who are: ${lower(a)}.`,
    failDetail: (a, allowed) => `Limited to students who are: ${lower(allowed)}; you chose “${lower(a)}”.`,
  });
  checks.push(enr.check);
  if (enr.missing) missing.push(enr.missing);

  // Field of study.
  const field = checkCriterion({
    label: "Field of study",
    criterion: e.fieldsOfStudy,
    actual: profile.fieldOfStudy || null,
    actualLabel: (v) => FIELD_OF_STUDY_LABELS[v],
    valueLabel: (v) => FIELD_OF_STUDY_LABELS[v],
    actualField: "your field of study",
    anyDetail: "Open to every field of study.",
    passDetail: (a) => `Open to ${lower(a)}.`,
    failDetail: (a, allowed) => `Limited to ${allowed}; you chose ${a}.`,
  });
  checks.push(field.check);
  if (field.missing) missing.push(field.missing);

  // Free-text requirements can never be checked from a profile: always unconfirmed.
  for (const text of e.additionalRequirements) {
    checks.push({
      label: "Additional requirement",
      state: "unknown",
      detail: `Also requires: ${text}`,
      credit: 1,
    });
    missing.push({
      who: "you",
      field: "Additional requirement",
      message: `The provider also requires: “${text}”. BridgeFund can’t check this; confirm it on the official site.`,
    });
  }

  return buildFactor("requirements", checks);
}

/* -------------------------------- Evaluation ------------------------------ */

function bandFor(score: number): MatchBand {
  if (score >= STRONG_FROM) return "strong";
  if (score >= GOOD_FROM) return "good";
  return "possible";
}

/**
 * Score one resource against one expense. Always returns an evaluation,
 * including for excluded listings, so the reason can be shown.
 */
export function evaluateResource(args: EvaluateArgs): MatchEvaluation {
  const { resource, expense, today } = args;
  const missing: MissingInfo[] = [];
  const exclusions: string[] = [];

  // Listing-level rules that no score can override.
  if (resource.archivedAt) {
    exclusions.push("This listing has been archived and is no longer offered.");
  }
  if (resource.verification === "expired") {
    exclusions.push("This listing has been marked expired.");
  }

  const deadline = deadlineFactor(args, missing);
  const factors: FactorResult[] = [
    locationFactor(args, missing),
    expenseFactor(args, missing),
    educationFactor(args, missing),
    opportunityTypeFactor(args, missing),
    deadline.factor,
    requirementsFactor(args, missing),
  ];

  for (const factor of factors) {
    for (const check of factor.checks) {
      if (check.state === "fail") exclusions.push(check.detail);
    }
  }

  const value = resourceValueFor(resource, expense);
  if (exclusions.length === 0 && value <= 0) {
    exclusions.push("This support would not reduce this expense.");
  }

  const reasons = factors.flatMap((f) =>
    f.checks.filter((c) => c.state === "pass").map((c) => c.detail),
  );

  // Hard rules override the score.
  if (exclusions.length > 0) {
    return {
      resourceId: resource.id,
      expenseId: expense.id,
      status: "excluded",
      score: 0,
      uncappedScore: 0,
      caps: [],
      band: "excluded",
      factors,
      reasons: [],
      exclusions,
      missing: [],
      value: 0,
      daysLeft: deadline.daysLeft,
    };
  }

  const hasUnknown = factors.some((f) => f.state === "unknown");
  const uncappedScore = Math.round(factors.reduce((n, f) => n + f.points, 0));

  const caps: ScoreCap[] = [];
  if (hasUnknown) {
    caps.push({
      limit: NEEDS_INFO_CAP,
      reason: "Some eligibility details are unconfirmed, so this can’t rank as a strong match.",
    });
  }
  const verification = effectiveVerification(resource, today);
  if (verification === "unverified") {
    caps.push({
      limit: UNVERIFIED_CAP,
      reason: "This listing has not been verified, so its score is capped.",
    });
    missing.push({
      who: "listing",
      field: "Verification",
      message: "This listing has not been verified. Confirm the details with the provider before you apply.",
    });
  } else if (verification === "requires_reverification") {
    caps.push({
      limit: UNVERIFIED_CAP,
      reason: "This listing’s verification is out of date, so its score is capped.",
    });
    missing.push({
      who: "listing",
      field: "Verification",
      message: "This listing’s verification is out of date. Confirm the details with the provider before you apply.",
    });
  }

  const score = Math.min(uncappedScore, ...caps.map((c) => c.limit));

  return {
    resourceId: resource.id,
    expenseId: expense.id,
    status: hasUnknown ? "needs_info" : "criteria_met",
    score,
    uncappedScore,
    caps,
    band: bandFor(score),
    factors,
    reasons,
    exclusions: [],
    missing,
    value,
    daysLeft: deadline.daysLeft,
  };
}

/** Ranking order: score, then more trustworthy listing, then bigger value, then sooner deadline. */
export function compareEvaluations(
  a: { evaluation: MatchEvaluation; resource: SupportResource },
  b: { evaluation: MatchEvaluation; resource: SupportResource },
  today: DateOnlyString,
): number {
  return (
    b.evaluation.score - a.evaluation.score ||
    VERIFICATION_RANK[effectiveVerification(b.resource, today)] -
      VERIFICATION_RANK[effectiveVerification(a.resource, today)] ||
    b.evaluation.value - a.evaluation.value ||
    (a.evaluation.daysLeft ?? Infinity) - (b.evaluation.daysLeft ?? Infinity)
  );
}
