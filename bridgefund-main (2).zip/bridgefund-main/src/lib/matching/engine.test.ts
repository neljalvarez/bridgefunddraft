import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { createDemoOpportunities, DEMO_PROFILE } from "@/data/demo-opportunities";
import { DEMO_RESOURCE_IDS as R, getSupportResources } from "@/data/support-resources";
import { addDays } from "@/lib/dates";
import { recommendForOpportunity } from "@/lib/gap/matching";
import { effectiveVerification } from "@/lib/resources/verification";
import { resourceValueFor } from "@/lib/resources/value";
import type { Expense, StudentProfile, SupportResource } from "@/types";

import {
  evaluateResource,
  MATCH_WEIGHTS,
  NEEDS_INFO_CAP,
  UNVERIFIED_CAP,
  type EvaluateArgs,
} from "./engine";

const today = "2026-11-13";
const catalog = getSupportResources(today);
const get = (id: string): SupportResource => {
  const r = catalog.find((x) => x.id === id);
  assert.ok(r, `missing demo resource ${id}`);
  return r;
};

const tuition: Expense = { id: "e-tuition", name: "Programme fee", amount: 1200, currency: "EUR", category: "tuition", mandatory: true };
const exam: Expense = { id: "e-exam", name: "Exam fee", amount: 180, currency: "USD", category: "exam_fees", mandatory: true };

const student: StudentProfile = { ...DEMO_PROFILE }; // PT, undergraduate, STEM, enrolled, need-based opt-in

function run(
  resource: SupportResource,
  over: Partial<EvaluateArgs> = {},
) {
  return evaluateResource({
    resource,
    expense: tuition,
    opportunity: { type: "program", country: "DE" },
    profile: student,
    today,
    ...over,
  });
}

describe("weights", () => {
  it("add up to 100", () => {
    assert.equal(Object.values(MATCH_WEIGHTS).reduce((a, b) => a + b, 0), 100);
  });
});

describe("a fully matching, verified listing", () => {
  const ev = run(get(R.tuitionGrant));
  it("meets every listed criterion and scores 100", () => {
    assert.equal(ev.status, "criteria_met");
    assert.equal(ev.score, 100);
    assert.equal(ev.band, "strong");
    assert.deepEqual(ev.missing, []);
    assert.ok(ev.reasons.length >= 5);
  });
  it("reports a score per factor that sums to the total", () => {
    const sum = ev.factors.reduce((n, f) => n + f.points, 0);
    assert.equal(Math.round(sum), ev.score);
  });
});

describe("hard restrictions override the score", () => {
  it("excludes a listing when the student's country is not eligible, whatever else matches", () => {
    const ev = run(get(R.tuitionGrant), { profile: { ...student, residenceCountry: "KE" } });
    assert.equal(ev.status, "excluded");
    assert.equal(ev.score, 0);
    assert.equal(ev.band, "excluded");
    assert.match(ev.exclusions.join(" "), /residents of/);
    assert.ok(ev.factors.find((f) => f.key === "expense")!.points === 25, "other factors still pass");
  });

  it("excludes on education level, opportunity type, and expense category", () => {
    assert.equal(run(get(R.tuitionGrant), { profile: { ...student, educationLevel: "secondary" } }).status, "excluded");
    assert.equal(run(get(R.tuitionGrant), { opportunity: { type: "exam", country: "DE" } }).status, "excluded");
    assert.equal(run(get(R.tuitionGrant), { expense: { ...tuition, category: "housing" } }).status, "excluded");
  });

  it("excludes a closed deadline", () => {
    const closed = { ...get(R.tuitionGrant), deadline: addDays(today, -1) };
    const ev = run(closed);
    assert.equal(ev.status, "excluded");
    assert.match(ev.exclusions.join(" "), /Closed on/);
  });

  it("accepts a deadline that is today", () => {
    assert.notEqual(run({ ...get(R.tuitionGrant), deadline: today }).status, "excluded");
  });

  it("excludes need-based listings when the student has not opted in", () => {
    const ev = run(get(R.tuitionGrant), { profile: { ...student, openToNeedBased: false } });
    assert.equal(ev.status, "excluded");
    assert.match(ev.exclusions.join(" "), /need-based/i);
  });

  it("excludes archived and manually expired listings", () => {
    assert.equal(run({ ...get(R.tuitionGrant), archivedAt: "2026-11-01T00:00:00Z" }).status, "excluded");
    const expired = get(R.retakeGrant);
    assert.equal(run(expired, { expense: exam, opportunity: { type: "exam", country: "PT" } }).status, "excluded");
  });

  it("an excluded listing never carries a score or a value", () => {
    const ev = run(get(R.tuitionGrant), { profile: { ...student, residenceCountry: "KE" } });
    assert.equal(ev.score, 0);
    assert.equal(ev.value, 0);
  });
});

describe("UNKNOWN is never confirmed eligibility", () => {
  it("a listing with unrecorded rules needs info and can never exceed the cap", () => {
    const ev = run(get(R.bootcampBursary));
    assert.equal(ev.status, "needs_info");
    assert.ok(ev.score <= NEEDS_INFO_CAP, `score ${ev.score}`);
    assert.notEqual(ev.band, "strong");
    assert.notEqual(ev.band, "good");
    const fields = ev.missing.map((m) => m.field);
    for (const f of ["Country of residence", "Education level", "Enrollment status", "Financial need", "Deadline", "Verification"]) {
      assert.ok(fields.includes(f), `expected missing "${f}", got ${fields.join(", ")}`);
    }
  });

  it("unknown earns no points for the unknown factor", () => {
    const ev = run(get(R.bootcampBursary));
    assert.equal(ev.factors.find((f) => f.key === "deadline")!.points, 0);
    assert.equal(ev.factors.find((f) => f.key === "education")!.points, 0);
  });

  it("an unknown STUDENT detail makes a restricted listing needs_info, not eligible", () => {
    const ev = run(get(R.tuitionGrant), { profile: { ...student, educationLevel: "" } });
    assert.equal(ev.status, "needs_info");
    assert.ok(ev.score <= NEEDS_INFO_CAP);
    const m = ev.missing.find((x) => x.field === "Education level");
    assert.equal(m?.who, "you");
  });

  it("an empty profile never produces criteria_met against restricted listings", () => {
    const empty: StudentProfile = { residenceCountry: "", educationLevel: "", fieldOfStudy: "", enrollment: "", openToNeedBased: true };
    for (const id of [R.tuitionGrant, R.housing, R.laptopLoan, R.transport]) {
      const ev = run(get(id), { profile: empty, expense: { ...tuition, category: get(id).categories[0]! } });
      assert.notEqual(ev.status, "criteria_met", id);
    }
  });

  it("\"Another country\" is unknown, not a failure", () => {
    const ev = run(get(R.tuitionGrant), { profile: { ...student, residenceCountry: "OTHER" } });
    assert.equal(ev.status, "needs_info");
  });

  it("requirements the engine cannot check are always unconfirmed", () => {
    const ev = run(get(R.intlTravel), { expense: { ...tuition, category: "transportation" } });
    assert.equal(ev.status, "needs_info");
    assert.ok(ev.missing.some((m) => /travelling abroad/.test(m.message)));
  });

  it("unknown need-based status is not treated as 'no need test'", () => {
    const ev = run(get(R.transitPass), { expense: { ...tuition, category: "transportation" } });
    assert.equal(ev.status, "needs_info");
    assert.ok(ev.missing.some((m) => m.field === "Financial need"));
  });

  it("an 'only' list with no values is treated as unrecorded, not as open", () => {
    const r = get(R.tuitionGrant);
    const broken: SupportResource = { ...r, eligibility: { ...r.eligibility, residence: { mode: "only", values: [] } } };
    assert.equal(run(broken).status, "needs_info");
  });

  it("a listing with no recorded expense categories is unknown, not a match", () => {
    assert.equal(run({ ...get(R.tuitionGrant), categories: [] }).status, "needs_info");
  });
});

describe("verification caps", () => {
  it("caps an unverified listing and says why", () => {
    const ev = run(get(R.skillsSponsorship));
    assert.equal(ev.uncappedScore, 100);
    assert.equal(ev.score, UNVERIFIED_CAP);
    assert.ok(ev.caps.some((c) => /not been verified/.test(c.reason)));
    assert.ok(ev.missing.some((m) => m.field === "Verification"));
  });

  it("treats a stale verification as requires re-verification", () => {
    const r = get(R.baobabFund);
    assert.equal(effectiveVerification(r, today), "requires_reverification");
    const ev = run(r, { profile: { ...student, residenceCountry: "KE" }, opportunity: { type: "program", country: "KE" } });
    assert.ok(ev.score <= UNVERIFIED_CAP);
  });

  it("effective status: closed deadline = expired; fresh verified stays verified", () => {
    assert.equal(effectiveVerification({ ...get(R.tuitionGrant), deadline: addDays(today, -1) }, today), "expired");
    assert.equal(effectiveVerification(get(R.tuitionGrant), today), "verified");
    assert.equal(effectiveVerification({ ...get(R.tuitionGrant), lastVerifiedDate: undefined }, today), "requires_reverification");
  });

  it("the demo catalog contains every verification state", () => {
    const states = new Set(catalog.map((r) => effectiveVerification(r, today)));
    for (const s of ["verified", "requires_reverification", "unverified", "expired"]) assert.ok(states.has(s as never), s);
  });
});

describe("amounts", () => {
  it("plans with the MINIMUM of a range, never the maximum", () => {
    const r = get(R.graduateStipend);
    assert.equal(r.value.kind, "range");
    assert.equal(resourceValueFor(r, { amount: 5000, currency: "USD" }), 500);
  });
  it("never exceeds the expense", () => {
    assert.equal(resourceValueFor(get(R.openDoorsWaiver), { amount: 75, currency: "EUR" }), 75);
    assert.equal(resourceValueFor({ value: { kind: "fixed", amount: 600, currency: "EUR" } }, { amount: 100, currency: "EUR" }), 100);
  });
});

describe("recommendations for a student's real expenses", () => {
  const [summer, certification] = createDemoOpportunities(today);
  const recs = recommendForOpportunity(summer!, student, catalog, today);

  it("every demo claim still resolves to a listing", () => {
    for (const opp of [summer!, certification!]) {
      for (const c of opp.claims) assert.ok(catalog.some((r) => r.id === c.resourceId), c.resourceId);
    }
  });

  it("recommends per expense, best score first, and never lists expired listings", () => {
    for (const [, list] of recs) {
      for (let i = 1; i < list.length; i++) assert.ok(list[i - 1]!.evaluation.score >= list[i]!.evaluation.score);
      assert.ok(list.every((r) => r.resource.id !== R.retakeGrant));
      assert.ok(list.every((r) => r.evaluation.status !== "excluded"));
    }
  });

  it("finds the tuition grant for the programme fee", () => {
    const fee = recs.get("demo-e-fee")!;
    assert.ok(fee.some((r) => r.resource.id === R.tuitionGrant && r.evaluation.status === "criteria_met"));
  });

  it("keeps Recommendation's existing shape (value, reasons, daysLeft, claim)", () => {
    const first = recs.get("demo-e-fee")![0]!;
    assert.equal(typeof first.value, "number");
    assert.ok(Array.isArray(first.reasons));
    assert.ok("daysLeft" in first && "claim" in first);
  });
});
