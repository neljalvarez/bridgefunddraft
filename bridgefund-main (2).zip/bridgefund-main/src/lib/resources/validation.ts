import { isValidDateOnly } from "@/lib/dates";
import type {
  Criterion,
  DateOnlyString,
  SupportResource,
} from "@/types";

/** A fresh, unverified listing for the admin form. */
export function createBlankResource(): SupportResource {
  const unknown = { mode: "unknown" } as const;
  return {
    id: "",
    name: "",
    provider: "",
    description: "",
    country: "GLOBAL",
    kind: "grant",
    categories: [],
    eligibility: {
      summary: "",
      residence: unknown,
      studyCountries: unknown,
      educationLevels: unknown,
      opportunityTypes: unknown,
      fieldsOfStudy: unknown,
      enrollment: unknown,
      needBased: "unknown",
      additionalRequirements: [],
    },
    value: { kind: "fixed", amount: 0, currency: "USD" },
    deadlineType: "unknown",
    officialUrl: "",
    sourceName: "",
    applicationInstructions: "",
    verification: "unverified",
    isDemo: false,
  };
}

/** Only https links are accepted: listings send students to external sites. */
export function isHttpsUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname.includes(".");
  } catch {
    return false;
  }
}

export type ResourceErrors = Partial<Record<string, string>>;

const criterionError = (label: string, c: Criterion<string>): string | undefined =>
  c.mode === "only" && c.values.length === 0
    ? `${label}: choose at least one, or set it to Any or Unknown.`
    : undefined;

export function validateResource(
  r: SupportResource,
  today: DateOnlyString,
): ResourceErrors {
  const e: ResourceErrors = {};
  if (!r.name.trim()) e.name = "Enter the resource name.";
  if (!r.provider.trim()) e.provider = "Enter the provider.";
  if (!r.description.trim()) e.description = "Enter a short description.";
  if (!r.country.trim()) e.country = "Choose a country or Global.";
  if (r.categories.length === 0) e.categories = "Choose at least one expense category.";
  if (!r.eligibility.summary.trim()) e.summary = "Summarise the eligibility requirements in plain language.";

  if (!isHttpsUrl(r.officialUrl)) e.officialUrl = "Enter the official website as a full https:// link.";
  if (r.applicationUrl && !isHttpsUrl(r.applicationUrl)) e.applicationUrl = "The application link must be a full https:// link.";
  if (!r.sourceName.trim()) e.sourceName = "Name the source (usually the provider).";
  if (!r.applicationInstructions.trim()) e.applicationInstructions = "Explain how to apply.";

  if (r.deadlineType === "fixed") {
    if (!r.deadline || !isValidDateOnly(r.deadline)) e.deadline = "Enter the deadline date.";
    else if (r.deadline < today && !r.archivedAt && r.verification !== "expired") {
      e.deadline = "That date has passed. The listing will show as expired.";
    }
  }

  const v = r.value;
  if (v.kind === "fixed" && !(v.amount > 0)) e.value = "Enter an amount above zero.";
  if (v.kind === "range") {
    if (!(v.min > 0)) e.value = "Enter a minimum above zero.";
    else if (v.max < v.min) e.value = "The maximum can’t be below the minimum.";
  }
  if (v.kind === "percent" && !(v.percent > 0 && v.percent <= 100)) e.value = "Enter a percentage from 1 to 100.";

  const el = r.eligibility;
  const crit =
    criterionError("Residence", el.residence) ??
    criterionError("Study location", el.studyCountries) ??
    criterionError("Education levels", el.educationLevels) ??
    criterionError("Opportunity types", el.opportunityTypes) ??
    criterionError("Fields of study", el.fieldsOfStudy) ??
    criterionError("Enrollment", el.enrollment);
  if (crit) e.eligibility = crit;

  return e;
}
