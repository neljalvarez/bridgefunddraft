import type { DateOnlyString, ISODateString, SupportResource } from "@/types";

import { isValidDateOnly } from "@/lib/dates";

/**
 * Administrator actions on a listing, as pure functions. They never mutate:
 * each returns the new listing (or an error message the UI can show).
 */

export const MIN_EVIDENCE_LENGTH = 10;

export type LifecycleResult =
  | { ok: true; resource: SupportResource }
  | { ok: false; error: string };

/** Fields that change what a student could rely on. Editing one un-verifies a verified listing. */
const MATERIAL_KEYS = [
  "provider",
  "country",
  "kind",
  "categories",
  "eligibility",
  "value",
  "deadline",
  "deadlineType",
  "officialUrl",
  "applicationUrl",
  "applicationInstructions",
] as const satisfies readonly (keyof SupportResource)[];

export function hasMaterialChange(
  before: SupportResource,
  after: SupportResource,
): boolean {
  return MATERIAL_KEYS.some(
    (key) => JSON.stringify(before[key] ?? null) !== JSON.stringify(after[key] ?? null),
  );
}

/**
 * Save an edit. The form can never set the verification status directly. If
 * a verified listing's material details change, it drops to "requires
 * re-verification" because the old evidence no longer covers what is shown.
 */
export function applyEdit(
  before: SupportResource,
  edited: SupportResource,
  now: ISODateString,
): SupportResource {
  const downgrade =
    before.verification === "verified" && hasMaterialChange(before, edited);
  return {
    ...edited,
    // Verification fields are controlled only by the lifecycle actions.
    verification: downgrade ? "requires_reverification" : before.verification,
    lastVerifiedDate: before.lastVerifiedDate,
    verificationNote: before.verificationNote,
    archivedAt: before.archivedAt,
    createdAt: before.createdAt,
    updatedAt: now,
  };
}

/**
 * Mark a listing verified. Requires evidence (what was checked and where) and
 * a verification date that is not in the future: BridgeFund never marks a
 * listing verified without a record of how.
 */
export function verifyResource(
  before: SupportResource,
  input: { date: DateOnlyString; note: string },
  today: DateOnlyString,
  now: ISODateString,
): LifecycleResult {
  const note = input.note.trim();
  if (!isValidDateOnly(input.date)) return { ok: false, error: "Enter a valid verification date." };
  if (input.date > today) return { ok: false, error: "The verification date can’t be in the future." };
  if (note.length < MIN_EVIDENCE_LENGTH) {
    return {
      ok: false,
      error: "Describe the evidence: what you checked and where (for example, the provider’s page and the date).",
    };
  }
  if (before.deadlineType === "fixed" && before.deadline && before.deadline < today) {
    return {
      ok: false,
      error: "This listing’s deadline has passed. Update the deadline (or mark it as rolling) before verifying it.",
    };
  }
  if (before.deadlineType === "unknown") {
    return { ok: false, error: "Record the deadline (or mark it as rolling) before verifying this listing." };
  }
  return {
    ok: true,
    resource: {
      ...before,
      verification: "verified",
      lastVerifiedDate: input.date,
      verificationNote: note,
      updatedAt: now,
    },
  };
}

/** Mark a listing expired. It disappears from matching and discovery. */
export function expireResource(
  before: SupportResource,
  reason: string,
  now: ISODateString,
): SupportResource {
  const note = reason.trim();
  return {
    ...before,
    verification: "expired",
    verificationNote: note || before.verificationNote,
    updatedAt: now,
  };
}

export function archiveResource(before: SupportResource, now: ISODateString): SupportResource {
  return { ...before, archivedAt: now, updatedAt: now };
}

/** Un-archive. The listing returns with its previous verification status. */
export function restoreResource(before: SupportResource, now: ISODateString): SupportResource {
  const restored: SupportResource = { ...before, updatedAt: now };
  delete restored.archivedAt;
  return restored;
}
