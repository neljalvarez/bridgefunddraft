import { convertAmount, formatCurrency, round2 } from "@/lib/currency";
import type { Expense, SupportResource } from "@/types";

/**
 * Potential value of a resource for one expense, in the expense's currency,
 * never more than the expense itself.
 *
 * For a range, planning uses the MINIMUM. The top of a range is a best case
 * the provider has not promised, so it is never counted toward a plan.
 */
export function resourceValueFor(
  resource: Pick<SupportResource, "value">,
  expense: Pick<Expense, "amount" | "currency">,
): number {
  const { value } = resource;
  switch (value.kind) {
    case "full":
      return expense.amount;
    case "percent":
      return round2((expense.amount * value.percent) / 100);
    case "range":
      return Math.min(
        expense.amount,
        convertAmount(value.min, value.currency, expense.currency),
      );
    case "fixed":
      return Math.min(
        expense.amount,
        convertAmount(value.amount, value.currency, expense.currency),
      );
  }
}

/** Human description of a resource's value independent of any expense. */
export function describeValue(resource: Pick<SupportResource, "value">): string {
  const { value } = resource;
  switch (value.kind) {
    case "full":
      return "Covers the full cost";
    case "percent":
      return `${value.percent}% of the cost`;
    case "range":
      return `${formatCurrency(value.min, value.currency)} to ${formatCurrency(value.max, value.currency)}`;
    case "fixed":
      return `Up to ${formatCurrency(value.amount, value.currency)}`;
  }
}

/** Largest amount the listing could pay, in USD. Null when it depends on the cost. */
export function maxValueUsd(resource: Pick<SupportResource, "value">): number | null {
  const { value } = resource;
  if (value.kind === "fixed") return convertAmount(value.amount, value.currency, "USD");
  if (value.kind === "range") return convertAmount(value.max, value.currency, "USD");
  return null;
}
