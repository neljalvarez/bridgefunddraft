import { getCountryName } from "@/config/countries";
import {
  EXPENSE_CATEGORY_LABELS,
  RESOURCE_KIND_LABELS,
} from "@/config/option-labels";
import { daysBetween } from "@/lib/dates";
import type { MatchEvaluation } from "@/lib/matching/engine";
import { maxValueUsd } from "@/lib/resources/value";
import type {
  BarrierCategory,
  Criterion,
  DateOnlyString,
  EducationLevel,
  ResourceVerificationStatus,
  SupportResource,
  SupportResourceKind,
} from "@/types";

import {
  effectiveVerification,
  isArchived,
  VERIFICATION_RANK,
} from "./verification";

/* ------------------------------ Search + filters --------------------------- */

export type DeadlineFilter = "all" | "open" | "closing_30" | "rolling";

export interface ResourceFilters {
  query: string;
  kind: SupportResourceKind | "all";
  category: BarrierCategory | "all";
  /** Student's country: keeps listings open to residents there. */
  country: string;
  education: EducationLevel | "all";
  verification: ResourceVerificationStatus | "all";
  deadline: DeadlineFilter;
  /**
   * Whether a listing whose rule for the chosen country/education is UNKNOWN
   * is shown. Off by default: unknown is not a match.
   */
  includeUnknown: boolean;
  includeExpired: boolean;
}

export const DEFAULT_FILTERS: ResourceFilters = {
  query: "",
  kind: "all",
  category: "all",
  country: "all",
  education: "all",
  verification: "all",
  deadline: "all",
  includeUnknown: false,
  includeExpired: false,
};

export function hasActiveFilters(f: ResourceFilters): boolean {
  return (
    f.query.trim() !== "" ||
    f.kind !== "all" ||
    f.category !== "all" ||
    f.country !== "all" ||
    f.education !== "all" ||
    f.verification !== "all" ||
    f.deadline !== "all" ||
    f.includeUnknown ||
    f.includeExpired
  );
}

function searchHaystack(r: SupportResource): string {
  return [
    r.name,
    r.provider,
    r.description,
    r.eligibility.summary,
    r.sourceName,
    RESOURCE_KIND_LABELS[r.kind],
    r.country === "GLOBAL" ? "global worldwide international" : getCountryName(r.country),
    ...r.categories.map((c) => EXPENSE_CATEGORY_LABELS[c]),
  ]
    .join(" ")
    .toLowerCase();
}

/** Every word typed must appear somewhere in the listing. */
export function matchesQuery(r: SupportResource, query: string): boolean {
  const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
  if (tokens.length === 0) return true;
  const hay = searchHaystack(r);
  return tokens.every((t) => hay.includes(t));
}

function criterionAllows<T extends string>(
  c: Criterion<T>,
  value: T,
  includeUnknown: boolean,
): boolean {
  if (c.mode === "any") return true;
  if (c.mode === "unknown" || c.values.length === 0) return includeUnknown;
  return c.values.includes(value);
}

/** Hard filter used by search. Does not look at a student's profile. */
export function filterResources(
  resources: SupportResource[],
  f: ResourceFilters,
  today: DateOnlyString,
): SupportResource[] {
  return resources.filter((r) => {
    const status = effectiveVerification(r, today);
    if (!f.includeExpired && status === "expired") return false;
    if (f.verification !== "all" && status !== f.verification) return false;
    if (f.kind !== "all" && r.kind !== f.kind) return false;
    if (f.category !== "all" && !r.categories.includes(f.category)) return false;
    if (f.country !== "all" && !criterionAllows(r.eligibility.residence, f.country, f.includeUnknown)) return false;
    if (f.education !== "all" && !criterionAllows(r.eligibility.educationLevels, f.education, f.includeUnknown)) return false;

    if (f.deadline !== "all") {
      const closed = r.deadlineType === "fixed" && !!r.deadline && r.deadline < today;
      if (f.deadline === "open" && closed) return false;
      if (f.deadline === "rolling" && r.deadlineType !== "rolling") return false;
      if (f.deadline === "closing_30") {
        if (r.deadlineType !== "fixed" || !r.deadline) return false;
        const days = daysBetween(today, r.deadline);
        if (days < 0 || days > 30) return false;
      }
    }
    return matchesQuery(r, f.query);
  });
}

/** Hide archived listings from anyone but administrators. */
export const notArchived = (r: SupportResource) => !isArchived(r);

/* ---------------------------------- Sorting -------------------------------- */

export type ResourceSort = "relevance" | "deadline" | "amount" | "verified" | "name";

export const SORT_LABELS: Record<ResourceSort, string> = {
  relevance: "Best match",
  deadline: "Deadline (soonest)",
  amount: "Amount (highest)",
  verified: "Recently verified",
  name: "Name (A to Z)",
};

export interface SortableResource {
  resource: SupportResource;
  /** Best evaluation against the chosen opportunity, if one is chosen. */
  evaluation?: MatchEvaluation | null;
}

function deadlineKey(r: SupportResource, today: DateOnlyString): number {
  if (r.deadlineType === "fixed" && r.deadline) {
    const days = daysBetween(today, r.deadline);
    return days >= 0 ? days : 100_000 + Math.abs(days); // closed: after everything open
  }
  return r.deadlineType === "rolling" ? 50_000 : 60_000; // rolling, then unknown
}

export function sortResources<T extends SortableResource>(
  items: T[],
  sort: ResourceSort,
  today: DateOnlyString,
): T[] {
  const byName = (a: T, b: T) => a.resource.name.localeCompare(b.resource.name);
  const copy = [...items];
  switch (sort) {
    case "relevance":
      return copy.sort(
        (a, b) =>
          (b.evaluation?.score ?? -1) - (a.evaluation?.score ?? -1) ||
          VERIFICATION_RANK[effectiveVerification(b.resource, today)] -
            VERIFICATION_RANK[effectiveVerification(a.resource, today)] ||
          byName(a, b),
      );
    case "deadline":
      return copy.sort(
        (a, b) => deadlineKey(a.resource, today) - deadlineKey(b.resource, today) || byName(a, b),
      );
    case "amount":
      return copy.sort(
        (a, b) =>
          (maxValueUsd(b.resource) ?? -1) - (maxValueUsd(a.resource) ?? -1) || byName(a, b),
      );
    case "verified":
      return copy.sort(
        (a, b) =>
          (b.resource.lastVerifiedDate ?? "").localeCompare(a.resource.lastVerifiedDate ?? "") ||
          byName(a, b),
      );
    case "name":
      return copy.sort(byName);
  }
}
