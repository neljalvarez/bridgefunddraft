import { daysBetween } from "@/lib/dates";
import type {
  DateOnlyString,
  ResourceVerificationStatus,
  SupportResource,
} from "@/types";

/** A verification older than this needs to be checked again. */
export const REVERIFY_AFTER_DAYS = 180;

type VerificationFields = Pick<
  SupportResource,
  "verification" | "lastVerifiedDate" | "deadline" | "deadlineType"
>;

/** True once a fixed application deadline is in the past. */
export function isDeadlinePassed(
  resource: Pick<SupportResource, "deadline" | "deadlineType">,
  today: DateOnlyString,
): boolean {
  return (
    resource.deadlineType === "fixed" &&
    !!resource.deadline &&
    resource.deadline < today
  );
}

/**
 * The status a student should see, computed from the stored status and the
 * calendar so a listing can never stay "Verified" on stale evidence:
 *  - a closed fixed deadline makes the listing Expired
 *  - "verified" without a verification date, or older than
 *    REVERIFY_AFTER_DAYS, drops to Requires re-verification
 */
export function effectiveVerification(
  resource: VerificationFields,
  today: DateOnlyString,
): ResourceVerificationStatus {
  if (resource.verification === "expired") return "expired";
  if (isDeadlinePassed(resource, today)) return "expired";
  if (resource.verification === "verified") {
    if (!resource.lastVerifiedDate) return "requires_reverification";
    if (daysBetween(resource.lastVerifiedDate, today) > REVERIFY_AFTER_DAYS) {
      return "requires_reverification";
    }
  }
  return resource.verification;
}

/** Days since the last verification, or null if it has never been verified. */
export function daysSinceVerified(
  resource: Pick<SupportResource, "lastVerifiedDate">,
  today: DateOnlyString,
): number | null {
  return resource.lastVerifiedDate
    ? daysBetween(resource.lastVerifiedDate, today)
    : null;
}

/** Archived listings are hidden from students and never matched. */
export function isArchived(resource: Pick<SupportResource, "archivedAt">) {
  return !!resource.archivedAt;
}

/**
 * Whether a student may be shown this listing as live support:
 * not archived and not expired.
 */
export function isListable(
  resource: SupportResource,
  today: DateOnlyString,
): boolean {
  return !isArchived(resource) && effectiveVerification(resource, today) !== "expired";
}

/** Higher = more trustworthy. Used only to break ties when ranking. */
export const VERIFICATION_RANK: Record<ResourceVerificationStatus, number> = {
  verified: 3,
  requires_reverification: 2,
  unverified: 1,
  expired: 0,
};
