import { getSupportResources } from "@/data/support-resources";
import type { ResourceCatalogData } from "@/lib/storage/resource-sanitize";
import type { DateOnlyString, SupportResource } from "@/types";

import { isListable } from "./verification";

/**
 * The full catalog: fictional demo listings (with any administrator edits
 * applied), plus listings administrators created. Includes archived and
 * expired listings so saved plans can still look them up; use `listable` for
 * anything a student browses or is matched to.
 */
export function buildCatalog(
  today: DateOnlyString,
  stored: ResourceCatalogData,
): SupportResource[] {
  const demo = stored.hideDemo
    ? []
    : getSupportResources(today).map((r) => stored.overrides[r.id] ?? r);
  return [...stored.created, ...demo];
}

/** Listings a student may see as live support. */
export function listable(
  resources: SupportResource[],
  today: DateOnlyString,
): SupportResource[] {
  return resources.filter((r) => isListable(r, today));
}
