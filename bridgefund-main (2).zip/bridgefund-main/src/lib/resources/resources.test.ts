import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { DEMO_RESOURCE_IDS as R, getSupportResources } from "@/data/support-resources";
import { addDays } from "@/lib/dates";
import type { SupportResource } from "@/types";

import { DEFAULT_FILTERS, filterResources, sortResources } from "./discovery";
import { applyEdit, archiveResource, expireResource, restoreResource, verifyResource } from "./lifecycle";
import { createBlankResource, validateResource } from "./validation";
import { effectiveVerification, isListable } from "./verification";

const today = "2026-11-13";
const now = "2026-11-13T09:00:00.000Z";
const catalog = getSupportResources(today);
const get = (id: string) => catalog.find((r) => r.id === id)!;

describe("demo data is clearly labelled", () => {
  it("marks every listing as DEMO DATA with an example.org link", () => {
    for (const r of catalog) {
      assert.equal(r.isDemo, true, r.id);
      assert.match(r.officialUrl, /^https:\/\/example\.org\/demo\//, r.id);
    }
  });
  it("has every field the spec requires", () => {
    for (const r of catalog) {
      for (const key of ["name", "provider", "description", "country", "kind", "categories", "eligibility", "value", "deadlineType", "officialUrl", "applicationInstructions", "verification"] as const) {
        assert.ok(r[key] !== undefined && r[key] !== "", `${r.id}.${key}`);
      }
      assert.ok(r.eligibility.summary.length > 0);
    }
  });
  it("only claims to be verified when it has a verification date and note", () => {
    for (const r of catalog.filter((x) => x.verification === "verified")) {
      assert.ok(r.lastVerifiedDate && r.verificationNote, r.id);
    }
  });
});

describe("lifecycle", () => {
  it("verification requires evidence and a non-future date", () => {
    const r = get(R.skillsSponsorship);
    assert.equal(verifyResource(r, { date: today, note: "" }, today, now).ok, false);
    assert.equal(verifyResource(r, { date: today, note: "short" }, today, now).ok, false);
    assert.equal(verifyResource(r, { date: addDays(today, 1), note: "Checked the provider page" }, today, now).ok, false);
    const done = verifyResource(r, { date: today, note: "Checked provider page and emailed team" }, today, now);
    assert.ok(done.ok && done.resource.verification === "verified" && done.resource.lastVerifiedDate === today);
  });

  it("refuses to verify a listing with a passed or unrecorded deadline", () => {
    const note = "Checked the provider page today";
    assert.equal(verifyResource({ ...get(R.tuitionGrant), deadline: addDays(today, -2) }, { date: today, note }, today, now).ok, false);
    assert.equal(verifyResource(get(R.bootcampBursary), { date: today, note }, today, now).ok, false);
  });

  it("editing a verified listing's material details sends it back for re-verification", () => {
    const before = get(R.tuitionGrant);
    const edited = applyEdit(before, { ...before, value: { kind: "fixed", amount: 900, currency: "EUR" } }, now);
    assert.equal(edited.verification, "requires_reverification");
    assert.equal(effectiveVerification(edited, today), "requires_reverification");
  });

  it("editing wording only keeps the verification", () => {
    const before = get(R.tuitionGrant);
    const edited = applyEdit(before, { ...before, description: "Reworded text." }, now);
    assert.equal(edited.verification, "verified");
  });

  it("the edit form cannot set verification directly", () => {
    const before = get(R.skillsSponsorship);
    const edited = applyEdit(before, { ...before, verification: "verified", lastVerifiedDate: today, verificationNote: "forged" }, now);
    assert.equal(edited.verification, "unverified");
    assert.equal(edited.lastVerifiedDate, undefined);
  });

  it("expire and archive remove a listing from student view; restore brings it back", () => {
    const r = get(R.tuitionGrant);
    assert.equal(isListable(r, today), true);
    assert.equal(isListable(expireResource(r, "Provider closed the fund", now), today), false);
    const archived = archiveResource(r, now);
    assert.equal(isListable(archived, today), false);
    const back = restoreResource(archived, now);
    assert.equal(isListable(back, today), true);
    assert.equal("archivedAt" in back, false);
  });
});

describe("validation", () => {
  it("a blank listing is invalid and starts unverified with every rule unknown", () => {
    const blank = createBlankResource();
    assert.equal(blank.verification, "unverified");
    assert.equal(blank.eligibility.residence.mode, "unknown");
    const errors = validateResource(blank, today);
    for (const k of ["name", "provider", "description", "categories", "officialUrl", "applicationInstructions", "summary", "value"]) {
      assert.ok(errors[k], k);
    }
  });
  it("rejects non-https links", () => {
    const r: SupportResource = { ...get(R.tuitionGrant), officialUrl: "http://example.org" };
    assert.ok(validateResource(r, today).officialUrl);
    assert.ok(validateResource({ ...r, officialUrl: "javascript:alert(1)" }, today).officialUrl);
    assert.equal(validateResource({ ...r, officialUrl: "https://example.org/x" }, today).officialUrl, undefined);
  });
  it("requires a deadline date for fixed deadlines and a sane range", () => {
    const r = get(R.tuitionGrant);
    assert.ok(validateResource({ ...r, deadline: undefined }, today).deadline);
    assert.ok(validateResource({ ...r, value: { kind: "range", min: 500, max: 100, currency: "USD" } }, today).value);
  });
  it("accepts every demo listing", () => {
    for (const r of catalog) {
      const { deadline: _d, ...errors } = validateResource(r, today);
      void _d;
      assert.deepEqual(errors, {}, r.id);
    }
  });
});

describe("discovery", () => {
  it("search needs every word to match", () => {
    assert.ok(filterResources(catalog, { ...DEFAULT_FILTERS, query: "laptop library" }, today).some((r) => r.id === R.laptopLoan));
    assert.equal(filterResources(catalog, { ...DEFAULT_FILTERS, query: "laptop zzzz" }, today).length, 0);
  });
  it("hides expired listings unless asked", () => {
    assert.ok(!filterResources(catalog, DEFAULT_FILTERS, today).some((r) => r.id === R.retakeGrant));
    assert.ok(filterResources(catalog, { ...DEFAULT_FILTERS, includeExpired: true }, today).some((r) => r.id === R.retakeGrant));
  });
  it("a country filter excludes listings restricted elsewhere and, by default, unknown ones", () => {
    const pt = filterResources(catalog, { ...DEFAULT_FILTERS, country: "PT" }, today).map((r) => r.id);
    assert.ok(pt.includes(R.tuitionGrant) && pt.includes(R.textbooks));
    assert.ok(!pt.includes(R.baobabFund), "Africa-only listing");
    assert.ok(!pt.includes(R.bootcampBursary), "unknown residence rule is not a match");
    const withUnknown = filterResources(catalog, { ...DEFAULT_FILTERS, country: "PT", includeUnknown: true }, today).map((r) => r.id);
    assert.ok(withUnknown.includes(R.bootcampBursary));
  });
  it("filters by category, kind, verification and deadline", () => {
    assert.ok(filterResources(catalog, { ...DEFAULT_FILTERS, category: "housing" }, today).every((r) => r.categories.includes("housing")));
    assert.ok(filterResources(catalog, { ...DEFAULT_FILTERS, kind: "free_alternative" }, today).every((r) => r.kind === "free_alternative"));
    assert.ok(filterResources(catalog, { ...DEFAULT_FILTERS, verification: "unverified" }, today).every((r) => effectiveVerification(r, today) === "unverified"));
    assert.ok(filterResources(catalog, { ...DEFAULT_FILTERS, deadline: "rolling" }, today).every((r) => r.deadlineType === "rolling"));
    const soon = filterResources(catalog, { ...DEFAULT_FILTERS, deadline: "closing_30" }, today);
    assert.ok(soon.length > 0 && soon.every((r) => r.deadlineType === "fixed" && r.deadline! <= addDays(today, 30)));
  });
  it("sorts by deadline: soonest first, rolling then unknown last", () => {
    const sorted = sortResources(filterResources(catalog, DEFAULT_FILTERS, today).map((resource) => ({ resource })), "deadline", today).map((x) => x.resource);
    const fixed = sorted.filter((r) => r.deadlineType === "fixed").map((r) => r.deadline!);
    assert.deepEqual(fixed, [...fixed].sort());
    assert.equal(sorted.at(-1)!.deadlineType, "unknown");
  });
  it("sorts by amount with percent/full (no fixed ceiling) last", () => {
    const sorted = sortResources(catalog.map((resource) => ({ resource })), "amount", today);
    assert.equal(sorted[0]!.resource.id, R.graduateStipend);
    assert.ok(["full", "percent"].includes(sorted.at(-1)!.resource.value.kind));
  });
});

describe("stored data is never trusted", () => {
  it("drops non-https links and treats unrecognised rules as UNKNOWN, not open", async () => {
    const { sanitizeResource, sanitizeCatalogData } = await import("@/lib/storage/resource-sanitize");
    const tampered = {
      ...get(R.tuitionGrant),
      officialUrl: "javascript:alert(1)",
      applicationUrl: "http://insecure.example",
      eligibility: { ...get(R.tuitionGrant).eligibility, residence: { mode: "everyone" }, educationLevels: { mode: "only", values: ["wizard"] } },
    };
    const clean = sanitizeResource(tampered)!;
    assert.equal(clean.officialUrl, "");
    assert.equal(clean.applicationUrl, undefined);
    assert.equal(clean.eligibility.residence.mode, "unknown");
    assert.equal(clean.eligibility.educationLevels.mode, "unknown");
    assert.equal(sanitizeResource({ ...get(R.tuitionGrant), lastVerifiedDate: undefined })!.verification, "requires_reverification");
    assert.equal(sanitizeResource({ name: "no id" }), null);
    assert.deepEqual(sanitizeCatalogData("garbage").created, []);
  });
  it("round-trips a valid listing unchanged", async () => {
    const { sanitizeResource } = await import("@/lib/storage/resource-sanitize");
    for (const r of catalog) {
      const back = sanitizeResource(JSON.parse(JSON.stringify(r)))!;
      assert.deepEqual(back.eligibility, r.eligibility, r.id);
      assert.equal(back.verification, r.verification, r.id);
      assert.deepEqual(back.value, r.value, r.id);
    }
  });
});
