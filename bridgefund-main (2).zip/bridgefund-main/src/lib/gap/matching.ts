import {
  compareEvaluations,
  evaluateResource,
  type MatchEvaluation,
} from "@/lib/matching/engine";
import { describeValue, resourceValueFor } from "@/lib/resources/value";
import type {
  DateOnlyString,
  Expense,
  StudentProfile,
  SupportClaim,
  SupportResource,
  TrackedOpportunity,
} from "@/types";

/*
 * Funding matches for the Gap Resolver. The scoring itself is the transparent
 * rule-based engine in src/lib/matching/engine.ts; this file applies it to a
 * student's real expenses and keeps the shapes the resolver already uses.
 */

export { describeValue, resourceValueFor };
export type { MatchEvaluation };

export interface Recommendation {
  resource: SupportResource;
  expenseId: string;
  /** Potential value in the expense's currency, capped at the expense amount. */
  value: number;
  /** Why this matched, in plain language (the checks that passed). */
  reasons: string[];
  /** Days until the application deadline; null for rolling or unknown. */
  daysLeft: number | null;
  /** The plan item for this resource + expense, if the student added one. */
  claim: SupportClaim | null;
  /** The full, explainable score for this pairing. */
  evaluation: MatchEvaluation;
}

type OpportunityContext = Pick<TrackedOpportunity, "type" | "claims"> & {
  country?: string;
};

interface RecommendArgs {
  expense: Expense;
  opportunity: OpportunityContext;
  profile: StudentProfile;
  resources: SupportResource[];
  today: DateOnlyString;
}

function toRecommendation(
  resource: SupportResource,
  expense: Expense,
  opportunity: OpportunityContext,
  evaluation: MatchEvaluation,
): Recommendation {
  return {
    resource,
    expenseId: expense.id,
    value: evaluation.value,
    reasons: evaluation.reasons,
    daysLeft: evaluation.daysLeft,
    claim:
      opportunity.claims.find(
        (c) => c.resourceId === resource.id && c.expenseId === expense.id,
      ) ?? null,
    evaluation,
  };
}

/**
 * Every listing scored against one expense, best first, INCLUDING the ones
 * excluded by a hard rule (with the reason), so the UI can explain why.
 */
export function evaluateForExpense({
  expense,
  opportunity,
  profile,
  resources,
  today,
}: RecommendArgs): Recommendation[] {
  return resources
    .map((resource) =>
      toRecommendation(
        resource,
        expense,
        opportunity,
        evaluateResource({ resource, expense, opportunity, profile, today }),
      ),
    )
    .sort((a, b) => compareEvaluations(a, b, today));
}

/**
 * Support that matches one expense: every listing that no hard rule excludes.
 * Listings with unknown eligibility are included but flagged "needs_info";
 * they are never presented as confirmed.
 */
export function recommendForExpense(args: RecommendArgs): Recommendation[] {
  return evaluateForExpense(args).filter(
    (r) => r.evaluation.status !== "excluded",
  );
}

/** Listings a hard rule excluded for this expense, with the reasons. */
export function excludedForExpense(args: RecommendArgs): Recommendation[] {
  return evaluateForExpense(args).filter(
    (r) => r.evaluation.status === "excluded",
  );
}

type OpportunityWithExpenses = OpportunityContext &
  Pick<TrackedOpportunity, "expenses">;

/** Recommendations for every expense of an opportunity, keyed by expense id. */
export function recommendForOpportunity(
  opportunity: OpportunityWithExpenses,
  profile: StudentProfile,
  resources: SupportResource[],
  today: DateOnlyString,
): Map<string, Recommendation[]> {
  const map = new Map<string, Recommendation[]>();
  for (const expense of opportunity.expenses) {
    map.set(
      expense.id,
      recommendForExpense({ expense, opportunity, profile, resources, today }),
    );
  }
  return map;
}

/**
 * How one listing fits an opportunity: its best-scoring expense, or null when
 * no expense passes every hard rule. `perExpense` always has one evaluation
 * per expense so the reasons for any exclusion can be shown.
 */
export function matchResourceToOpportunity(
  resource: SupportResource,
  opportunity: OpportunityWithExpenses,
  profile: StudentProfile,
  today: DateOnlyString,
): { best: Recommendation | null; perExpense: Recommendation[] } {
  const perExpense = opportunity.expenses.map((expense) =>
    toRecommendation(
      resource,
      expense,
      opportunity,
      evaluateResource({ resource, expense, opportunity, profile, today }),
    ),
  );
  const matches = perExpense
    .filter((r) => r.evaluation.status !== "excluded")
    .sort((a, b) => compareEvaluations(a, b, today));
  return { best: matches[0] ?? null, perExpense };
}
