import { isValidDateOnly } from "@/lib/dates";
import { isHttpsUrl } from "@/lib/resources/validation";
import {
  BARRIER_CATEGORIES,
  CURRENCY_CODES,
  EDUCATION_LEVELS,
  ENROLLMENT_STATUSES,
  FIELDS_OF_STUDY,
  RESOURCE_KINDS,
  RESOURCE_VERIFICATION_STATUSES,
  type Criterion,
  type ResourceEligibility,
  type ResourceValue,
  type SupportResource,
  type TriState,
} from "@/types";

/**
 * Catalog data lives in browser storage, where it can be edited by hand or
 * left by an older app version. Everything read from it is coerced into a
 * valid shape. Links that are not https are dropped so a tampered
 * `javascript:` URL can never become a clickable link.
 */

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj =>
  typeof v === "object" && v !== null && !Array.isArray(v);
const str = (v: unknown, fallback = "") => (typeof v === "string" ? v : fallback);
const num = (v: unknown, fallback = 0) =>
  typeof v === "number" && Number.isFinite(v) ? v : fallback;
const oneOf = <T extends string>(list: readonly T[], v: unknown, fallback: T): T =>
  list.includes(v as T) ? (v as T) : fallback;
const dateOrUndef = (v: unknown) =>
  typeof v === "string" && isValidDateOnly(v) ? v : undefined;
const urlOrEmpty = (v: unknown) => (typeof v === "string" && isHttpsUrl(v) ? v : "");

const OPPORTUNITY_TYPES = ["program", "scholarship", "course", "exam"] as const;
const DEADLINE_TYPES = ["fixed", "rolling", "unknown"] as const;
const TRI_STATES = ["yes", "no", "unknown"] as const;

/** Anything unrecognised becomes UNKNOWN, never "any". */
function criterion<T extends string>(
  v: unknown,
  allowed: readonly T[] | null,
): Criterion<T> {
  if (!isObj(v)) return { mode: "unknown" };
  if (v.mode === "any") return { mode: "any" };
  if (v.mode === "only" && Array.isArray(v.values)) {
    const values = v.values.filter(
      (x): x is T =>
        typeof x === "string" &&
        (allowed ? allowed.includes(x as T) : /^[A-Z]{2}$/.test(x)),
    );
    return values.length > 0 ? { mode: "only", values } : { mode: "unknown" };
  }
  return { mode: "unknown" };
}

function sanitizeEligibility(v: unknown): ResourceEligibility {
  const e = isObj(v) ? v : {};
  return {
    summary: str(e.summary),
    residence: criterion<string>(e.residence, null),
    studyCountries: criterion<string>(e.studyCountries, null),
    educationLevels: criterion(e.educationLevels, EDUCATION_LEVELS),
    opportunityTypes: criterion(e.opportunityTypes, OPPORTUNITY_TYPES),
    fieldsOfStudy: criterion(e.fieldsOfStudy, FIELDS_OF_STUDY),
    enrollment: criterion(e.enrollment, ENROLLMENT_STATUSES),
    needBased: oneOf<TriState>(TRI_STATES, e.needBased, "unknown"),
    additionalRequirements: (Array.isArray(e.additionalRequirements)
      ? e.additionalRequirements
      : []
    )
      .filter((x): x is string => typeof x === "string" && x.trim() !== "")
      .map((x) => x.trim()),
  };
}

function sanitizeValue(v: unknown): ResourceValue {
  if (!isObj(v)) return { kind: "fixed", amount: 0, currency: "USD" };
  const currency = oneOf(CURRENCY_CODES, v.currency, "USD");
  switch (v.kind) {
    case "full":
      return { kind: "full" };
    case "percent":
      return { kind: "percent", percent: Math.min(100, Math.max(0, num(v.percent))) };
    case "range": {
      const min = Math.max(0, num(v.min));
      return { kind: "range", min, max: Math.max(min, num(v.max)), currency };
    }
    default:
      return { kind: "fixed", amount: Math.max(0, num(v.amount)), currency };
  }
}

export function sanitizeResource(v: unknown): SupportResource | null {
  if (!isObj(v) || typeof v.id !== "string" || !v.id) return null;
  const deadline = dateOrUndef(v.deadline);
  const deadlineType = oneOf(DEADLINE_TYPES, v.deadlineType, "unknown");
  const applicationUrl = urlOrEmpty(v.applicationUrl);
  const lastVerifiedDate = dateOrUndef(v.lastVerifiedDate);
  const verification = oneOf(RESOURCE_VERIFICATION_STATUSES, v.verification, "unverified");

  return {
    id: v.id,
    name: str(v.name, "Untitled resource"),
    provider: str(v.provider),
    description: str(v.description),
    country: str(v.country, "GLOBAL"),
    kind: oneOf(RESOURCE_KINDS, v.kind, "other"),
    categories: (Array.isArray(v.categories) ? v.categories : []).filter(
      (c): c is (typeof BARRIER_CATEGORIES)[number] =>
        BARRIER_CATEGORIES.includes(c as never),
    ),
    eligibility: sanitizeEligibility(v.eligibility),
    value: sanitizeValue(v.value),
    // A fixed deadline with no valid date is not a known deadline.
    deadline: deadlineType === "fixed" ? deadline : undefined,
    deadlineType: deadlineType === "fixed" && !deadline ? "unknown" : deadlineType,
    officialUrl: urlOrEmpty(v.officialUrl),
    sourceName: str(v.sourceName),
    applicationUrl: applicationUrl || undefined,
    applicationInstructions: str(v.applicationInstructions),
    // "Verified" with no date is never trusted as verified.
    verification:
      verification === "verified" && !lastVerifiedDate ? "requires_reverification" : verification,
    lastVerifiedDate,
    verificationNote: typeof v.verificationNote === "string" ? v.verificationNote : undefined,
    isDemo: v.isDemo === true,
    archivedAt: typeof v.archivedAt === "string" && v.archivedAt ? v.archivedAt : undefined,
    createdAt: typeof v.createdAt === "string" ? v.createdAt : undefined,
    updatedAt: typeof v.updatedAt === "string" ? v.updatedAt : undefined,
  };
}

/** What the admin tools persist on top of the built-in demo catalog. */
export interface ResourceCatalogData {
  version: 1;
  /** Edited copies of demo listings, keyed by id. */
  overrides: Record<string, SupportResource>;
  /** Listings an administrator created. */
  created: SupportResource[];
  /** Hide the fictional demo listings entirely. */
  hideDemo: boolean;
}

export const EMPTY_CATALOG: ResourceCatalogData = {
  version: 1,
  overrides: {},
  created: [],
  hideDemo: false,
};

export function sanitizeCatalogData(raw: unknown): ResourceCatalogData {
  if (!isObj(raw) || raw.version !== 1) return EMPTY_CATALOG;
  const overrides: Record<string, SupportResource> = {};
  if (isObj(raw.overrides)) {
    for (const [id, value] of Object.entries(raw.overrides)) {
      const r = sanitizeResource(value);
      if (r && r.id === id) overrides[id] = r;
    }
  }
  return {
    version: 1,
    overrides,
    created: (Array.isArray(raw.created) ? raw.created : [])
      .map(sanitizeResource)
      .filter((r): r is SupportResource => r !== null),
    hideDemo: raw.hideDemo === true,
  };
}
