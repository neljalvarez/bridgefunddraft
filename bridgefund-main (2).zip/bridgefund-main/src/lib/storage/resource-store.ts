import { newId } from "@/lib/id";
import type { SupportResource } from "@/types";

import {
  EMPTY_CATALOG,
  sanitizeCatalogData,
  type ResourceCatalogData,
} from "./resource-sanitize";

/**
 * Client-side funding resource catalog store.
 *
 * Same pattern as student-store.ts: until Supabase tables exist, the edits
 * administrators make live in this browser's localStorage, and this module is
 * the ONLY place that touches that storage. Replace the read/write functions
 * (keeping `resourceActions`) when the database lands.
 *
 * IMPORTANT: localStorage is per browser and editable by whoever uses it. It
 * is a development stand-in, not a place to keep a shared, trusted catalog.
 */

const STORAGE_KEY = "bridgefund:resource-catalog:v1";

let cache: ResourceCatalogData | null = null;
const listeners = new Set<() => void>();
let storageListenerAttached = false;

function notify() {
  for (const listener of listeners) listener();
}

function read(): ResourceCatalogData {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? sanitizeCatalogData(JSON.parse(raw)) : EMPTY_CATALOG;
  } catch {
    return EMPTY_CATALOG;
  }
}

function commit(next: ResourceCatalogData) {
  cache = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Storage blocked: changes last only for this session.
  }
  notify();
}

export function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  if (!storageListenerAttached) {
    storageListenerAttached = true;
    window.addEventListener("storage", (event) => {
      if (event.key === STORAGE_KEY || event.key === null) {
        cache = null;
        notify();
      }
    });
  }
  return () => listeners.delete(listener);
}

export function getSnapshot(): ResourceCatalogData | null {
  if (typeof window === "undefined") return null;
  cache ??= read();
  return cache;
}

export function getServerSnapshot(): null {
  return null;
}

const current = () => getSnapshot() ?? EMPTY_CATALOG;

export const resourceActions = {
  /** Add a new listing. New listings always start unverified. */
  create(draft: SupportResource, now: string): SupportResource {
    const created: SupportResource = {
      ...draft,
      id: `usr-${newId()}`,
      verification: "unverified",
      lastVerifiedDate: undefined,
      verificationNote: undefined,
      archivedAt: undefined,
      createdAt: now,
      updatedAt: now,
    };
    const data = current();
    commit({ ...data, created: [created, ...data.created] });
    return created;
  },

  /** Save a listing: a created one in place, or an edited demo one as an override. */
  save(resource: SupportResource) {
    const data = current();
    if (data.created.some((r) => r.id === resource.id)) {
      commit({
        ...data,
        created: data.created.map((r) => (r.id === resource.id ? resource : r)),
      });
    } else {
      commit({ ...data, overrides: { ...data.overrides, [resource.id]: resource } });
    }
  },

  setHideDemo(hideDemo: boolean) {
    commit({ ...current(), hideDemo });
  },

  /** Discard every edit and created listing; restores the built-in demo catalog. */
  reset() {
    commit(EMPTY_CATALOG);
  },
};
