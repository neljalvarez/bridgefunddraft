import {
  BarChart3,
  Bookmark,
  FileText,
  FolderKanban,
  FolderOpen,
  Handshake,
  Inbox,
  ListChecks,
  Search,
  LayoutDashboard,
  type LucideIcon,
  Settings,
  Wallet,
} from "lucide-react";

import type { UserRole } from "@/types";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export interface RoleConfig {
  label: string;
  /** Landing route after sign-in. */
  home: string;
  nav: NavItem[];
}

/**
 * Single source of truth for per-role navigation.
 * To add a page to a dashboard: create the route, then add one entry here.
 */
export const ROLE_CONFIG: Record<UserRole, RoleConfig> = {
  student: {
    label: "Student",
    home: "/student/dashboard",
    nav: [
      { label: "Overview", href: "/student/dashboard", icon: LayoutDashboard },
      { label: "My Opportunities", href: "/student/opportunities", icon: FolderOpen },
      { label: "Gap Resolver", href: "/student/resolver", icon: Wallet },
      { label: "Funding Matches", href: "/student/matches", icon: Handshake },
      { label: "Find Funding", href: "/student/resources", icon: Search },
      { label: "Applications", href: "/student/applications", icon: FileText },
      { label: "Saved Resources", href: "/student/saved", icon: Bookmark },
      { label: "Impact", href: "/student/impact", icon: BarChart3 },
      { label: "Settings", href: "/student/settings", icon: Settings },
    ],
  },
  organization: {
    label: "Organization",
    home: "/organization/dashboard",
    nav: [
      {
        label: "Dashboard",
        href: "/organization/dashboard",
        icon: LayoutDashboard,
      },
      { label: "Programs", href: "/organization/programs", icon: FolderKanban },
      { label: "Applications", href: "/organization/applications", icon: Inbox },
      { label: "Impact", href: "/organization/impact", icon: BarChart3 },
    ],
  },
  admin: {
    label: "Admin",
    home: "/admin/dashboard",
    nav: [
      { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
      { label: "Funding Resources", href: "/admin/resources", icon: ListChecks },
    ],
  },
};

export interface PublicNavItem {
  label: string;
  href: string;
}

/** Landing-page navigation. Hash links resolve from any public page. */
export const PUBLIC_NAV: PublicNavItem[] = [
  { label: "How It Works", href: "/#how-it-works" },
  { label: "For Students", href: "/#for-students" },
  { label: "For Organizations", href: "/#for-organizations" },
  { label: "Our Impact", href: "/#impact" },
  { label: "About", href: "/#about" },
];

export function getRoleHome(role: UserRole): string {
  return ROLE_CONFIG[role].home;
}
