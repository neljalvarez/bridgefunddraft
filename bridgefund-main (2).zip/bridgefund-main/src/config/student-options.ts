import {
  BookOpen,
  Gift,
  GraduationCap,
  Handshake,
  Laptop,
  type LucideIcon,
  ReceiptText,
  Sparkles,
  Wallet,
} from "lucide-react";

import type { SupportResourceKind } from "@/types";

import { RESOURCE_KIND_LABELS } from "./option-labels";

export {
  ENROLLMENT_LABELS,
  EDUCATION_LEVEL_LABELS,
  FIELD_OF_STUDY_LABELS,
  OPPORTUNITY_TYPE_LABELS,
} from "./option-labels";

export interface ResourceKindMeta {
  label: string;
  /** Short explanation of how this kind of support helps. */
  description: string;
  icon: LucideIcon;
  /** Student-directed estimates that need no provider approval. */
  selfDirected: boolean;
}

export const RESOURCE_KIND_META: Record<SupportResourceKind, ResourceKindMeta> = {
  fee_waiver: {
    label: RESOURCE_KIND_LABELS.fee_waiver,
    description: "The provider removes or reduces a fee.",
    icon: ReceiptText,
    selfDirected: false,
  },
  sponsorship: {
    label: RESOURCE_KIND_LABELS.sponsorship,
    description: "A sponsor pays part or all of a cost.",
    icon: Handshake,
    selfDirected: false,
  },
  grant: {
    label: RESOURCE_KIND_LABELS.grant,
    description: "Funding you don’t repay.",
    icon: Wallet,
    selfDirected: false,
  },
  free_alternative: {
    label: RESOURCE_KIND_LABELS.free_alternative,
    description: "A free option you can use instead of paying.",
    icon: BookOpen,
    selfDirected: true,
  },
  equipment_loan: {
    label: RESOURCE_KIND_LABELS.equipment_loan,
    description: "Borrow equipment instead of buying or renting it.",
    icon: Laptop,
    selfDirected: false,
  },
  other: {
    label: RESOURCE_KIND_LABELS.other,
    description: "Another verified form of help.",
    icon: Gift,
    selfDirected: false,
  },
};

export const GENERIC_ICON = Sparkles;
export const EDUCATION_ICON = GraduationCap;
