import type {
  ApplicationStatus,
  ClaimStatus,
  OpportunityStatus,
  ResourceVerificationStatus,
  VerificationStatus,
} from "@/types";

export type BadgeTone = "neutral" | "info" | "success" | "warning" | "danger";

export interface StatusMeta {
  label: string;
  tone: BadgeTone;
}

export const APPLICATION_STATUS_META: Record<ApplicationStatus, StatusMeta> = {
  draft: { label: "Draft", tone: "neutral" },
  submitted: { label: "Submitted", tone: "info" },
  under_review: { label: "Under review", tone: "warning" },
  approved: { label: "Approved", tone: "success" },
  declined: { label: "Declined", tone: "danger" },
  withdrawn: { label: "Withdrawn", tone: "neutral" },
};

export const CLAIM_STATUS_META: Record<ClaimStatus, StatusMeta> = {
  planned: { label: "Planned", tone: "neutral" },
  applied: { label: "Applied · pending", tone: "warning" },
  approved: { label: "Approved", tone: "success" },
  received: { label: "Received", tone: "success" },
  declined: { label: "Declined", tone: "danger" },
};

export const OPPORTUNITY_STATUS_META: Record<OpportunityStatus, StatusMeta> = {
  draft: { label: "Draft", tone: "neutral" },
  active: { label: "Saved", tone: "info" },
  archived: { label: "Archived", tone: "neutral" },
};

export const VERIFICATION_STATUS_META: Record<VerificationStatus, StatusMeta> = {
  pending: { label: "Pending verification", tone: "warning" },
  verified: { label: "Verified", tone: "success" },
  rejected: { label: "Rejected", tone: "danger" },
};

export interface ResourceVerificationMeta extends StatusMeta {
  /** What the status means, shown to students next to the badge. */
  description: string;
}

/** Verification states of a funding resource listing. */
export const RESOURCE_VERIFICATION_META: Record<
  ResourceVerificationStatus,
  ResourceVerificationMeta
> = {
  verified: {
    label: "Verified",
    tone: "success",
    description:
      "BridgeFund confirmed these details against the provider’s own source. Providers decide who receives funding.",
  },
  requires_reverification: {
    label: "Requires re-verification",
    tone: "warning",
    description:
      "These details were verified before but are out of date or have changed. Confirm them with the provider.",
  },
  unverified: {
    label: "Unverified",
    tone: "neutral",
    description:
      "BridgeFund has not verified these details. Confirm everything with the provider before you apply.",
  },
  expired: {
    label: "Expired",
    tone: "danger",
    description: "This listing has closed or is no longer offered.",
  },
};
