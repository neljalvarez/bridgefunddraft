import type {
  BarrierCategory,
  DeadlineType,
  EducationLevel,
  EnrollmentStatus,
  FieldOfStudy,
  OpportunityType,
  SupportResourceKind,
} from "@/types";

/**
 * Plain-text labels for domain enums. Deliberately free of React and icon
 * imports so pure logic (the matching engine, validation, tests) can use them.
 * Icons and tones live in the other config files and build on these.
 */

export const OPPORTUNITY_TYPE_LABELS: Record<OpportunityType, string> = {
  program: "Program",
  scholarship: "Scholarship",
  course: "Course",
  exam: "Exam",
};

export const EDUCATION_LEVEL_LABELS: Record<EducationLevel, string> = {
  secondary: "Secondary / high school",
  vocational: "Vocational or technical",
  undergraduate: "Undergraduate",
  graduate: "Graduate (master’s)",
  doctoral: "Doctoral",
  other: "Other / self-directed learning",
};

export const FIELD_OF_STUDY_LABELS: Record<FieldOfStudy, string> = {
  stem: "Science, technology, engineering, math",
  business: "Business and economics",
  health: "Health and medicine",
  social_sciences: "Social sciences",
  humanities: "Humanities",
  arts: "Arts and design",
  trades: "Trades and applied skills",
  other: "Other",
};

export const ENROLLMENT_LABELS: Record<EnrollmentStatus, string> = {
  enrolled: "Currently enrolled in education",
  applying: "Applying to programs",
  not_enrolled: "Not currently enrolled",
};

export const EXPENSE_CATEGORY_LABELS: Record<BarrierCategory, string> = {
  tuition: "Tuition",
  application_fees: "Application fees",
  exam_fees: "Exam fees",
  learning_materials: "Learning materials",
  technology: "Technology",
  transportation: "Transportation",
  housing: "Housing",
  other: "Other",
};

export const RESOURCE_KIND_LABELS: Record<SupportResourceKind, string> = {
  fee_waiver: "Fee waiver",
  sponsorship: "Sponsorship",
  grant: "Grant",
  free_alternative: "Free alternative",
  equipment_loan: "Equipment loan",
  other: "Other support",
};

export const DEADLINE_TYPE_LABELS: Record<DeadlineType, string> = {
  fixed: "Fixed deadline",
  rolling: "Rolling, no fixed deadline",
  unknown: "Deadline not recorded",
};
